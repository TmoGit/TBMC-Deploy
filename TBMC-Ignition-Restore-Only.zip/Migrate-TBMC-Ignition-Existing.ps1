#requires -Version 5.1
<#
.SYNOPSIS
  TBMC restore-only launcher for an existing Ignition + MariaDB Windows Server.
.DESCRIPTION
  Does NOT install or reinstall Ignition or MariaDB. Validates installed services,
  available encrypted VM133 artifacts and age identity, then delegates restoration
  to the repository's original ignition\Restore-Ignition.ps1.

  This launcher cannot safely recreate undocumented restore procedures. If the
  repository's restorer lacks a supported interface or required artifacts, it
  stops with a precise report rather than guessing at database/Gateway writes.

  Default interactive mode runs preflight and asks for approval. Use
  -PreflightOnly to validate without restoring.
#>
[CmdletBinding()]
param(
  [string]$RepositoryPath = 'C:\TBMC\TBMC-Deploy',
  [string]$ConfigPath,
  [string]$ArtifactPath,
  [string]$AgeIdentityPath = 'C:\TBMC\Secure\deploy.key',
  [switch]$PreflightOnly,
  [switch]$Resume
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:Problems = New-Object System.Collections.Generic.List[string]
$script:Warnings = New-Object System.Collections.Generic.List[string]
$script:Results = [ordered]@{
  timestamp = (Get-Date).ToString('o')
  mode = $(if ($PreflightOnly) { 'preflight' } else { 'interactive-restore' })
  target = $env:COMPUTERNAME
  sourceRole = 'Ignition Server + MariaDB contextual database'
  installedSoftwareSkipped = @('Ignition Gateway','MariaDB')
  repository = $null
  ignitionService = $null
  mariaDbService = $null
  ignitionVersion = $null
  mariaDbVersion = $null
  restorer = $null
  encryptedArtifactCount = 0
  encryptedArtifacts = @()
  artifactCategories = [ordered]@{}
  problems = @()
  warnings = @()
  state = 'preflight'
  restoreExitCode = $null
}
function Add-Problem([string]$Message) {
  $script:Problems.Add($Message)
  Write-Host "BLOCKED: $Message" -ForegroundColor Red
}
function Add-Warning([string]$Message) {
  $script:Warnings.Add($Message)
  Write-Host "NOTICE: $Message" -ForegroundColor Yellow
}
function Is-Admin {
  $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
  $principal = New-Object Security.Principal.WindowsPrincipal($identity)
  return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
function Test-PSParse([string]$FilePath) {
  $tokens=$null; $errors=$null
  [void][System.Management.Automation.Language.Parser]::ParseFile($FilePath,[ref]$tokens,[ref]$errors)
  if (@($errors).Count -gt 0) { throw "Syntax errors in $FilePath : $(@($errors|Select-Object -First 3|ForEach-Object Message) -join '; ')" }
}
function Resolve-Repo([string]$Preferred) {
  $candidatePaths = New-Object System.Collections.Generic.List[string]
  $candidatePaths.Add($Preferred)
  $candidatePaths.Add($PSScriptRoot)
  $candidatePaths.Add((Join-Path $PSScriptRoot 'TBMC-Deploy-main'))
  $candidatePaths.Add((Join-Path $PSScriptRoot 'TBMC-Deploy'))
  foreach ($desktop in @([Environment]::GetFolderPath('Desktop'),(Join-Path $env:USERPROFILE 'Desktop'))) {
    if ($desktop -and (Test-Path -LiteralPath $desktop -PathType Container)) {
      $candidatePaths.Add((Join-Path $desktop 'TBMC-Deploy-main'))
      $candidatePaths.Add((Join-Path $desktop 'TBMC-Deploy'))
    }
  }
  foreach($p in @($candidatePaths|Select-Object -Unique)) {
    if ($p -and (Test-Path -LiteralPath (Join-Path $p 'ignition\Restore-Ignition.ps1') -PathType Leaf)) {
      return (Resolve-Path -LiteralPath $p).ProviderPath
    }
  }
  return $null
}
function Read-DisplayVersion([string]$DisplayNameRegex) {
  $paths=@('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
           'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*')
  $matches=@(Get-ItemProperty -Path $paths -ErrorAction SilentlyContinue |
    Where-Object { $_.DisplayName -and $_.DisplayName -match $DisplayNameRegex })
  if ($matches.Count -eq 0) { return '' }
  return ($matches | Select-Object -First 1 -ExpandProperty DisplayVersion)
}
function Get-AgeExe {
  $cmd = Get-Command age.exe -ErrorAction SilentlyContinue
  if ($cmd) { return $cmd.Source }
  foreach ($candidate in @('C:\TBMC\Tools\age.exe','C:\TBMC\Installers\age.exe',
                           'C:\Program Files\age\age.exe')) {
    if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
  }
  return $null
}
function Save-Report([string]$State) {
  $script:Results.state=$State
  $script:Results.problems=@($script:Problems.ToArray())
  $script:Results.warnings=@($script:Warnings.ToArray())
  $dir='C:\TBMC\Logs'
  if (-not (Test-Path -LiteralPath $dir)) { [void](New-Item -Path $dir -ItemType Directory -Force) }
  $file=Join-Path $dir 'TBMC-Ignition-Restore-Readiness.json'
  try {
    $json=([pscustomobject]$script:Results | ConvertTo-Json -Depth 8)
    [IO.File]::WriteAllText($file,$json,[Text.UTF8Encoding]::new($false))
    Write-Host "Report: $file" -ForegroundColor Gray
  } catch {
    Write-Warning "Could not write readiness report: $($_.Exception.Message)"
  }
}
function Find-RestoreParameter([System.Management.Automation.CommandInfo]$Command,[string[]]$Names) {
  foreach($n in $Names) { if ($Command.Parameters.ContainsKey($n)) { return $n } }
  return $null
}

Write-Host ''
Write-Host '===============================================================' -ForegroundColor Cyan
Write-Host ' TBMC - IGNITION SERVER RESTORE-ONLY (PREINSTALLED SOFTWARE)' -ForegroundColor Cyan
Write-Host '===============================================================' -ForegroundColor Cyan
Write-Host 'Ignition and MariaDB installers will NOT be launched.' -ForegroundColor Green
Write-Host 'No QuestDB or InfluxDB installation is performed on this server.' -ForegroundColor Gray
Write-Host ''

if (-not (Is-Admin)) {
  Add-Problem 'Run this script from an elevated Administrator PowerShell session (or right-click the included CMD launcher and choose Run as administrator).'
}
$repo=Resolve-Repo $RepositoryPath
if (-not $repo) {
  Add-Problem 'Cannot find ignition\Restore-Ignition.ps1 under C:\TBMC\TBMC-Deploy or the extracted TBMC-Deploy-main desktop folder.'
} else {
  $script:Results.repository=$repo
  $restoreScript=Join-Path $repo 'ignition\Restore-Ignition.ps1'
  $script:Results.restorer=$restoreScript
  try { Test-PSParse $restoreScript } catch { Add-Problem $_.Exception.Message }
  Write-Host "Repository: $repo"
  Write-Host "Restoration entry point: $restoreScript"
}

if (-not $ConfigPath -and $repo) { $ConfigPath=Join-Path $repo 'config\client.json' }
$config=$null
if (-not $ConfigPath -or -not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) {
  Add-Problem "Missing client configuration: $ConfigPath"
} else {
  try {
    $config=Get-Content -LiteralPath $ConfigPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    if($null -eq $config) {throw 'JSON document is empty'}
    Write-Host "Configuration: $ConfigPath"
  } catch { Add-Problem "Invalid client.json: $($_.Exception.Message)" }
}
if ($null -ne $config) {
  if (-not $config.PSObject.Properties['ignitionVersion']) {
    Add-Problem 'client.json has no ignitionVersion property; expected 8.3.4.'
  } elseif ([string]$config.ignitionVersion -ne '8.3.4') {
    Add-Problem "Client ignitionVersion is '$($config.ignitionVersion)'; expected source 8.3.4."
  }
  if ($config.PSObject.Properties['serverA'] -and $null -ne $config.serverA -and
      $config.serverA.PSObject.Properties['enableExternalConnections'] -and
      $config.serverA.enableExternalConnections -eq $true) {
    Add-Problem 'serverA.enableExternalConnections is true. Disable live PLC/MQTT/remote endpoints before restore.'
  }
}
if (-not (Test-Path -LiteralPath $AgeIdentityPath -PathType Leaf)) {
  Add-Problem "Missing age identity key: $AgeIdentityPath"
} else {
  try {
    $first=Get-Content -LiteralPath $AgeIdentityPath -TotalCount 4 -ErrorAction Stop | Where-Object { $_ -match '^AGE-SECRET-KEY-' }
    if (-not $first) { Add-Problem 'age identity file does not appear to contain an age private identity.' }
  } catch { Add-Problem "Cannot read age identity key: $($_.Exception.Message)" }
}
$ageExe=Get-AgeExe
if (-not $ageExe) { Add-Problem 'age.exe is missing. Supply the compatible Windows age.exe in C:\TBMC\Tools or on PATH.' }
else { Write-Host "Decryption utility: $ageExe" }

$ignService=@(Get-Service -ErrorAction SilentlyContinue | Where-Object {
    $_.Name -match '^Ignition$|^IgnitionGateway$' -or $_.DisplayName -match '^Ignition( Gateway)?$'
}) | Select-Object -First 1
if (-not $ignService) { Add-Problem 'Ignition Windows service was not found. No installer will be executed.' }
else {
  $script:Results.ignitionService="{0}: {1}" -f $ignService.Name,$ignService.Status
  Write-Host "Ignition installed: service $($ignService.Name) ($($ignService.Status))" -ForegroundColor Green
}
$script:Results.ignitionVersion=Read-DisplayVersion '^Ignition( Gateway)?$'
if ($script:Results.ignitionVersion -and $script:Results.ignitionVersion -notmatch '^8\.3\.4(\.|$)') {
  Add-Problem "Installed Ignition version appears to be $($script:Results.ignitionVersion), not 8.3.4."
} elseif (-not $script:Results.ignitionVersion) {
  Add-Warning 'The registry did not expose Ignition version. Confirm 8.3.4 b2026030309 in the Gateway UI before applying restore.'
}

$mdbService=@(Get-Service -ErrorAction SilentlyContinue | Where-Object {
  $_.Name -match '^MariaDB|^MySQL' -or $_.DisplayName -match '^MariaDB'
}) | Select-Object -First 1
if (-not $mdbService) { Add-Problem 'MariaDB Windows service was not found. No installer will be executed.' }
else {
  $script:Results.mariaDbService="{0}: {1}" -f $mdbService.Name,$mdbService.Status
  Write-Host "MariaDB installed: service $($mdbService.Name) ($($mdbService.Status))" -ForegroundColor Green
}
$script:Results.mariaDbVersion=Read-DisplayVersion '^MariaDB'
if ($script:Results.mariaDbVersion -and $script:Results.mariaDbVersion -notmatch '^10\.11(\.|$)') {
  Add-Problem "Installed MariaDB version appears to be $($script:Results.mariaDbVersion), not 10.11.x."
} elseif (-not $script:Results.mariaDbVersion) {
  Add-Warning 'The registry did not expose MariaDB version. Confirm the MariaDB service binary is 10.11.x before restoration.'
}

if (-not $ArtifactPath -and $repo) { $ArtifactPath=Join-Path $repo 'artifacts' }
if (-not $ArtifactPath -or -not (Test-Path -LiteralPath $ArtifactPath -PathType Container)) {
  Add-Problem "Artifact folder missing: $ArtifactPath"
} else {
  $files=@(Get-ChildItem -LiteralPath $ArtifactPath -Recurse -File -ErrorAction SilentlyContinue)
  $enc=@($files | Where-Object { $_.Name -match '\.age$' })
  $script:Results.encryptedArtifactCount=$enc.Count
  $script:Results.encryptedArtifacts=@($enc | ForEach-Object {
    [pscustomobject]@{RelativePath=$_.FullName.Substring($ArtifactPath.Length).TrimStart('\');Bytes=$_.Length}
  })
  Write-Host "Encrypted backup artifacts: $($enc.Count)" -ForegroundColor Cyan
  if ($enc.Count -lt 4) {Add-Problem 'Too few encrypted artifacts for a full Ignition+MariaDB migration.'}
  $lfsPointers=@($enc | Where-Object { $_.Length -lt 200 } | Where-Object {
    try { [IO.File]::ReadAllText($_.FullName).StartsWith('version https://git-lfs.github.com/spec/v1') } catch { $false }
  })
  if ($lfsPointers.Count -gt 0) {
    Add-Problem "Found $($lfsPointers.Count) Git LFS pointer file(s), not decrypted backup content. Fetch the actual artifacts."
  }
  $cat=[ordered]@{
    mariadb=@($enc|Where-Object{$_.Name -match '(?i)maria|ignition[_-]?config|contextual|sql.*dump'}).Count
    projects=@($enc|Where-Object{$_.Name -match '(?i)project'}).Count
    modules=@($enc|Where-Object{$_.Name -match '(?i)module'}).Count
    gateway=@($enc|Where-Object{$_.Name -match '(?i)gateway|commission|ignition[.]conf'}).Count
    historian=@($enc|Where-Object{$_.Name -match '(?i)historian|csv'}).Count
  }
  $script:Results.artifactCategories=$cat
  foreach($item in $cat.GetEnumerator()) { Write-Host ('  {0}: {1} candidate file(s)' -f $item.Key,$item.Value) }
  if ($cat.mariadb -eq 0) { Add-Problem 'No encrypted MariaDB contextual database artifact identifiable by filename. Confirm full dump is present before restoration.' }
  if ($cat.projects -eq 0) { Add-Problem 'No encrypted Ignition project archive identifiable by filename.' }
  if ($cat.modules -eq 0) { Add-Problem 'No encrypted Ignition module archive identifiable by filename.' }
  if ($cat.gateway -eq 0) { Add-Problem 'No encrypted Gateway configuration artifacts identifiable by filename.' }
  if ($cat.historian -eq 0) {Add-Warning 'No CSV historian artifact identifiable by filename; verify coverage in transfer manifest.'}
  $manifests=@($files|Where-Object{$_.Name -match '(?i)manifest'})
  if($manifests.Count -eq 0) {Add-Warning 'No transfer/checksum manifest found. Artifact integrity should be verified against source manifest.'}
}

# Discover and validate the restorer's actual public command parameters.
$restoreArgs=@{}
if($repo -and (Test-Path -LiteralPath (Join-Path $repo 'ignition\Restore-Ignition.ps1'))) {
  try {
    $restorerText=[IO.File]::ReadAllText((Join-Path $repo 'ignition\Restore-Ignition.ps1'))
    if ($restorerText -match '(?im)^[^#\r\n]*\b(?:Install-Ignition\.ps1|Install-Database\.ps1|msiexec(?:\.exe)?\s+/(?:i|package))\b') {
      Add-Problem 'Restore-Ignition.ps1 appears to call a software installation routine. Review it before running restore-only mode.'
    }
    $cmd=Get-Command -Name (Join-Path $repo 'ignition\Restore-Ignition.ps1') -ErrorAction Stop
    foreach($pair in @(
      @{Keys=@('ConfigPath','ConfigurationPath','ClientConfigPath');Value=$ConfigPath},
      @{Keys=@('AgeIdentityPath','AgeKeyPath','IdentityFile','IdentityPath','AgeIdentityKey');Value=$AgeIdentityPath},
      @{Keys=@('ArtifactPath','ArtifactsPath','ArtifactDirectory','ArtifactRoot','BackupPath');Value=$ArtifactPath}
    )) {
      $n=Find-RestoreParameter $cmd $pair.Keys
      if ($n) { $restoreArgs[$n]=$pair.Value }
    }
    if($Resume -and $cmd.Parameters.ContainsKey('Resume')) { $restoreArgs['Resume']=$true }
    $required=New-Object System.Collections.Generic.List[string]
    foreach($p in $cmd.Parameters.Values) {
      $must=$false
      foreach($a in $p.Attributes) {
        if(($a -is [System.Management.Automation.ParameterAttribute]) -and $a.Mandatory) {$must=$true}
      }
      if($must -and -not $restoreArgs.ContainsKey($p.Name)) { $required.Add($p.Name) }
    }
    if($required.Count -gt 0) {
      Add-Problem "Restore script requires additional parameters not mapped safely: $($required -join ', '). Check its usage before running."
    }
    if(-not $restoreArgs.ContainsKey('AgeIdentityPath') -and -not $restoreArgs.ContainsKey('AgeKeyPath') -and
       -not $restoreArgs.ContainsKey('IdentityFile') -and -not $restoreArgs.ContainsKey('IdentityPath') -and
       -not $restoreArgs.ContainsKey('AgeIdentityKey')) {
      Add-Warning 'Restore script does not expose a recognized age identity parameter. Confirm it reads identity from client.json or the environment.'
    }
    Write-Host 'Restoration parameter interface inspected.' -ForegroundColor Gray
  } catch { Add-Problem "Could not inspect repository restoration interface: $($_.Exception.Message)" }
}

Save-Report $(if($script:Problems.Count -eq 0){'preflight-passed'}else{'blocked'})
if($script:Problems.Count -gt 0) {
  Write-Host ''
  Write-Host "Preflight BLOCKED ($($script:Problems.Count) issue(s)). No restoration performed." -ForegroundColor Red
  exit 2
}
Write-Host ''
Write-Host 'Preflight passed. Ignition and MariaDB will NOT be reinstalled.' -ForegroundColor Green
Write-Host 'The existing repo Restore-Ignition.ps1 will perform the restoration.' -ForegroundColor Yellow
Write-Host 'A native .gwbk was not captured; this must be verified as a supplemental restore.' -ForegroundColor Yellow

if($PreflightOnly) {
  Write-Host 'Preflight-only mode: exiting without changes to applications/databases.'
  exit 0
}

Write-Host ''
Write-Host 'WARNING: Restoring MariaDB and Ignition can replace current application data.' -ForegroundColor Red
Write-Host 'Make a recoverable backup of the current destination first.' -ForegroundColor Red
Write-Host 'Do NOT proceed if this Windows server contains live or unbacked-up data.' -ForegroundColor Red
$approval=Read-Host 'To authorize full RESTORATION (not software installation), type RESTORE'
if($approval -cne 'RESTORE') {
  Save-Report 'declined'
  Write-Host 'No changes made to installed applications or databases.' -ForegroundColor Yellow
  exit 0
}

Write-Host 'Starting the existing TBMC restoration workflow...' -ForegroundColor Cyan
Push-Location $repo
try {
  $global:LASTEXITCODE=0
  & $restoreScript @restoreArgs
  if(-not $?) { throw 'Restore-Ignition.ps1 failed. Inspect its output and logs.' }
  if($LASTEXITCODE -is [int] -and $LASTEXITCODE -ne 0) {
    throw "Restore-Ignition.ps1 returned an external process exit code of $LASTEXITCODE."
  }
  $script:Results.restoreExitCode=0
  Write-Host 'Restoration script returned successfully; checking visible outcomes...' -ForegroundColor Green

  $ignData='C:\Program Files\Inductive Automation\Ignition\data\projects'
  $expected=@('TBMC','TBMC_CT_DEMO','SCADA_Template_Project','samplequickstart')
  if(Test-Path -LiteralPath $ignData -PathType Container) {
    $missing=@($expected|Where-Object { -not(Test-Path -LiteralPath (Join-Path $ignData $_) -PathType Container) })
    if($missing.Count -gt 0) {Add-Warning "Expected project directories not found in default location: $($missing -join ', '). Check the configured Gateway data location."}
    else {Write-Host 'All four expected project directories found at default location.' -ForegroundColor Green}
  } else { Add-Warning 'Default Gateway project directory not found. Verify projects in the Gateway user interface.' }
  Add-Warning 'Database record count, module activation and live Gateway behavior require post-restore checks; these have NOT been established by this wrapper.'
  Save-Report 'restore-invoked-validation-pending'
  Write-Host ''
  Write-Host 'Restore command finished. Validate MariaDB records, four projects, module state, and Gateway health BEFORE enabling external connections.' -ForegroundColor Yellow
} catch {
  Add-Problem "Restoration failed or returned a nonzero status: $($_.Exception.Message)"
  Save-Report 'restore-failed'
  exit 1
} finally { Pop-Location }
