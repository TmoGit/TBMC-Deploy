TBMC Ignition Server: RESTORE-ONLY launcher
============================================

Use this on the CLIENT Ignition Server only, AFTER you have installed:
- Ignition Gateway 8.3.4 (build 2026030309)
- MariaDB 10.11.x

Expected staged files:
  C:\TBMC\TBMC-Deploy\ignition\Restore-Ignition.ps1
  C:\TBMC\TBMC-Deploy\config\client.json
  C:\TBMC\TBMC-Deploy\artifacts\ (encrypted Ignition/MariaDB backups)
  C:\TBMC\Secure\deploy.key
  age.exe available on PATH or C:\TBMC\Tools\age.exe

1. Extract this ZIP on the client Ignition Server desktop.
2. Right-click Run-TBMC-Ignition-Restore-Only.cmd and choose Run as administrator.
3. The script will verify installed services, configuration, encrypted artifacts,
   and the restoration script's parameters. It never runs software installers.
4. Review any blockers; preflight report:
     C:\TBMC\Logs\TBMC-Ignition-Restore-Readiness.json
5. If checks pass and the destination is safe to overwrite, type RESTORE when
   prompted. The launcher then calls the repo's Restore-Ignition.ps1.
6. Validate all four projects, custom modules, MariaDB data and gateway health
   before enabling PLC, MQTT, alarm, historian or external database connections.

To run preflight only without restoration, from Administrator PowerShell:
  .\Migrate-TBMC-Ignition-Existing.ps1 -PreflightOnly

IMPORTANT LIMITATION
This file delegates the actual backup-specific work to the repo's existing
Restore-Ignition.ps1. The private repository's actual restoration code was NOT
available during construction, so we cannot certify that all expected objects
will restore or that its parameters match the fallback mapping. If the preflight
reports missing or unsupported parameters, the actual repository restorer
must be inspected and adjusted. Do not bypass those checks.

The wrapper does NOT automatically overwrite current destination MariaDB
accounts or Gateway databases; the repository restorer controls those steps.
A native Ignition .gwbk was unavailable at source, so supplemental restoration
and end-to-end validation are essential.
