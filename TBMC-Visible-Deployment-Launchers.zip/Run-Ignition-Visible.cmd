@echo off
setlocal EnableExtensions
chcp 65001 >nul
title TBMC Ignition - Visible deployment and diagnostics
color 0F

echo ===========================================================
echo TBMC IGNITION - VISIBLE INSTALLATION LAUNCHER
echo ===========================================================
echo This console will remain open and show errors and progress.
echo.

set "TBMC_BATCH_PATH=%~f0"
fltmc >nul 2>&1
if errorlevel 1 (
    echo Requesting Administrator permission via Windows UAC...
    powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "try { Start-Process -FilePath $env:TBMC_BATCH_PATH -Verb RunAs -ErrorAction Stop } catch { Write-Host ('Elevation failed: ' + $_.Exception.Message) -ForegroundColor Red; exit 1 }" 
    if errorlevel 1 (
        echo.
        echo Please right-click Run-Ignition-Visible.cmd and choose Run as administrator.
        pause
    )
    exit /b
)

set "TBMC_BATCH_PATH=%~f0"
set "TBMC_PS1=%~dp0tbmc.ps1"
set "TBMC_LOGDIR=C:\TBMC\Logs"
set "TBMC_LOG=%TBMC_LOGDIR%\Ignition-Launcher-LastRun.log"
if not exist "%TBMC_LOGDIR%" mkdir "%TBMC_LOGDIR%"
if not exist "%TBMC_PS1%" (
    echo ERROR: Cannot find tbmc.ps1 beside this launcher.
    echo The updated ZIP must be extracted as a complete folder.
    goto :finish
)

echo PowerShell script: "%TBMC_PS1%"
echo Persistent log: "%TBMC_LOG%"
echo.
echo Starting software checks and deployment preflight...
echo Downloads may take a while. Do not close this window.
echo Before installing or restoring anything, the underlying script
 echo will ask for explicit approval.
echo -----------------------------------------------------------
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; try { Start-Transcript -Path $env:TBMC_LOG -Append -ErrorAction Stop | Out-Null; Write-Host 'Transcript started'; & $env:TBMC_PS1; $rc=if($?) {0} else {1}; try {Stop-Transcript | Out-Null} catch {}; exit $rc } catch { Write-Host ('LAUNCHER ERROR: ' + $_.Exception.Message) -ForegroundColor Red; try {Stop-Transcript | Out-Null} catch {}; exit 1 }"
set "TBMC_EXIT=%ERRORLEVEL%"
echo.
echo ===========================================================
echo IGNITION LAUNCHER FINISHED -- Exit code: %TBMC_EXIT%
echo Log: %TBMC_LOG%
echo ===========================================================
if not "%TBMC_EXIT%"=="0" (
 echo An error or missing prerequisite was reported. Review the output above.
 echo No need to restart from scratch after fixing the problem.
) else (
 echo Script completed. Confirm validation before enabling live connections.
)
:finish
echo.
echo This window will stay open until you close it with the X button.
cmd /k
