TBMC VISIBLE & LOGGED DEPLOYMENT LAUNCHERS
========================================

Use this package instead of double-clicking tbmc.ps1 directly.

ON THE IGNITION WINDOWS SERVER:
1. Copy this ZIP to the Windows desktop and extract ALL files together.
2. Right-click Run-Ignition-Visible.cmd and choose Run as administrator.
3. Keep the visible console open while it checks and acquires software.
4. Read any errors and review the preflight outcome before approving live installation.

ON THE TIME-SERIES DATABASE WINDOWS SERVER:
1. Extract all files together on that server.
2. Right-click Run-Database-Visible.cmd and choose Run as administrator.
3. Review the result as above.

The new launchers use the exact existing tbmc.ps1 and tbmc-database.ps1
from the previous automatic acquisition package, unchanged. They print
progress into a visible console, attempt UAC elevation if not already
running as Administrator, and keep the window open at completion.

PERSISTENT LOGS
  C:\TBMC\Logs\Ignition-Launcher-LastRun.log
  C:\TBMC\Logs\Database-Launcher-LastRun.log

The log is appended; examine the bottom for the most recent run.
The original deployment orchestrator can also produce state journal and
software-readiness JSON under C:\TBMC\Logs.

SAFETY
- The launcher does not bypass prereqs or start live installation without
  the original explicit Yes/No confirmation.
- Exact versions, code-signing, source hashes, valid backups, keys and
  destination-specific configuration remain mandatory where applicable.
- If UAC elevation cannot be granted, it displays a message instead.
- Original launchers have not been runtime-tested on the client machines.
- Do not email/paste full logs without removing passwords, tokens and
  internal infrastructure details.
