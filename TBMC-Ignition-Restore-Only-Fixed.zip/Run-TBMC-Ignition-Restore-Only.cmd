@echo off
setlocal
chcp 65001 >nul
title TBMC Ignition - Restore-Only (Ignition + MariaDB already installed)
echo.
echo TBMC IGNITION SERVER - RESTORE ONLY
echo Ignition and MariaDB will NOT be installed or reinstalled.
echo Run this command file as Administrator for the restore operation.
echo.
if exist "C:\TBMC\Tools\age\age.exe" set "PATH=C:\TBMC\Tools\age;%PATH%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Migrate-TBMC-Ignition-Existing.ps1"
set "TBMC_CODE=%ERRORLEVEL%"
echo.
echo Finished with exit code %TBMC_CODE%.
echo Preflight report: C:\TBMC\Logs\TBMC-Ignition-Restore-Readiness.json
echo This window stays open so you can read any errors.
echo.
pause
exit /b %TBMC_CODE%
