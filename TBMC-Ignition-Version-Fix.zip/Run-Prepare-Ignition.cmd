@echo off
setlocal
set "SCRIPT=%~dp0Prepare-Ignition-8.3.4.ps1"
if not exist "%SCRIPT%" (
  echo Missing %SCRIPT%
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
if errorlevel 1 (
  echo.
  echo Preparation did not complete. See the error above.
) else (
  echo.
  echo Ignition installer preparation completed. The live installation has NOT run.
)
pause
