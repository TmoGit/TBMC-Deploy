# TBMC - Ignition 8.3.4 installer preparation
# Does not install software or run the deployment orchestrator.
# Windows PowerShell 5.1+.
[CmdletBinding()]
param(
    [string]$RepoRoot = 'C:\TBMC\TBMC-Deploy',
    [string]$InstallerDirectory = 'C:\TBMC\Installers',
    [string]$VendorSha256 = '',
    [switch]$SkipDownload
)
$ErrorActionPreference = 'Stop'
$installerName = 'ignition-8.3.4-windows-x64-installer.exe'
$downloadUrl = 'https://releases.inductiveautomation.com/release/8.3.4/2026030309/ignition-8.3.4-windows-x64-installer.exe'
$configPath = Join-Path $RepoRoot 'config\client.json'
$installerPath = Join-Path $InstallerDirectory $installerName

function Fail([string]$Message) { throw "TBMC Ignition preparation stopped: $Message" }
function Verify-ShaText([string]$Value) {
    if ($Value -notmatch '^[a-fA-F0-9]{64}$') {
        Fail 'A 64-digit SHA-256 checksum from the official Ignition 8.3.4 archive is required. Nothing was changed.'
    }
    return $Value.ToUpperInvariant()
}

try {
    Write-Host 'TBMC Ignition 8.3.4 installer preparation' -ForegroundColor Cyan
    if (-not (Test-Path -LiteralPath $configPath -PathType Leaf)) {
        Fail "Client configuration was not found: $configPath. Run the desktop deployment preparation first."
    }
    $configText = Get-Content -LiteralPath $configPath -Raw
    $cfg = $configText | ConvertFrom-Json
    if ($null -eq $cfg) { Fail "Invalid JSON configuration at $configPath" }

    if (-not $VendorSha256) {
        Write-Host ''
        Write-Host 'Find SHA-256 for the Windows x64 installer on the official archive:'
        Write-Host 'https://inductiveautomation.com/downloads/archive/8.3.4'
        Write-Host 'This value must come from the vendor download page, not the downloaded file itself.'
        $VendorSha256 = Read-Host 'Paste official SHA-256 (64 hexadecimal characters)'
    }
    $expected = Verify-ShaText $VendorSha256.Trim()

    New-Item -ItemType Directory -Force -Path $InstallerDirectory | Out-Null
    if (-not (Test-Path -LiteralPath $installerPath -PathType Leaf)) {
        if ($SkipDownload) { Fail "Installer is absent: $installerPath. Copy the official installer into this folder and rerun." }
        Write-Host "Downloading exact vendor installer to $installerPath ..."
        $partialPath = "$installerPath.partial"
        if (Test-Path -LiteralPath $partialPath) { Remove-Item -LiteralPath $partialPath -Force }
        try {
            # Windows PowerShell: force TLS 1.2 where available.
            [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
            Invoke-WebRequest -Uri $downloadUrl -OutFile $partialPath -UseBasicParsing -MaximumRedirection 5
            Move-Item -LiteralPath $partialPath -Destination $installerPath -Force
        } catch {
            if (Test-Path -LiteralPath $partialPath) { Remove-Item -LiteralPath $partialPath -Force }
            Fail "Download failed: $($_.Exception.Message). You can place the official EXE in $InstallerDirectory manually and rerun."
        }
    } else {
        Write-Host "Using existing installer: $installerPath"
    }

    $actual = (Get-FileHash -LiteralPath $installerPath -Algorithm SHA256).Hash.ToUpperInvariant()
    if ($actual -ne $expected) {
        Fail "SHA-256 mismatch. Expected vendor hash $expected but file hash is $actual. No config changes made."
    }
    Write-Host 'Vendor SHA-256 matches downloaded installer.' -ForegroundColor Green

    $sig = Get-AuthenticodeSignature -LiteralPath $installerPath
    if ($sig.Status -ne 'Valid') {
        Fail "Authenticode signature status is '$($sig.Status)'. No config changes made."
    }
    $publisher = [string]$sig.SignerCertificate.Subject
    if ($publisher -notmatch 'Inductive Automation') {
        Fail "Unexpected publisher in signed installer: $publisher. No config changes made."
    }
    Write-Host "Valid code signature: $publisher" -ForegroundColor Green

    # Preserve the existing client-specific deployment configuration and unrelated settings.
    $updates = @{
        ignitionVersion = '8.3.4'
        ignitionInstallerName = $installerName
        ignitionInstallerUrl = $downloadUrl
        ignitionInstallerSha256 = $expected
        ignitionInstallerArguments = '/quiet'
    }
    foreach ($key in $updates.Keys) {
        $existing = $cfg.PSObject.Properties[$key]
        if ($null -eq $existing) {
            $cfg | Add-Member -MemberType NoteProperty -Name $key -Value $updates[$key]
        } else {
            $existing.Value = $updates[$key]
        }
    }
    $backupPath = "$configPath.before-ignition-$(Get-Date -Format 'yyyyMMdd-HHmmss').bak"
    Copy-Item -LiteralPath $configPath -Destination $backupPath
    $json = $cfg | ConvertTo-Json -Depth 50
    [System.IO.File]::WriteAllText($configPath, $json + [Environment]::NewLine, (New-Object System.Text.UTF8Encoding($false)))
    Write-Host "Updated: $configPath" -ForegroundColor Green
    Write-Host "Backup of previous client config: $backupPath"
    Write-Host 'No installation has been started.' -ForegroundColor Yellow
    Write-Host 'Next: rerun C:\tbmc.ps1 to continue its prerequisite checks.' -ForegroundColor Cyan
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
