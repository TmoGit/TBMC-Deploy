# TBMC — Commission 06A.2

Controlled live integration completed on 26 November 2026, Asia/Taipei. BRX5-02-01 remains enabled on MFCS U01 and BRX5-02-02 is enabled on MFCS U02. Both show actual process values simultaneously on the original Plasmid-814 overview. All 12 process members and three existing CPP references per vessel are enabled; no automatic rollback/fallback was deployed.

## Association and source verification

Acropolis designated BRX5-02-02 → U02 for this test. Current direct OPC Name returns Biostat B TWIN_R_814; U01 returns Biostat B TWIN_L_814. This verifies remote server identity and the designated mapping, not an independently witnessed field or serial-number association. An optional guessed Type metadata address returned Bad and was not used for eligibility. All 24 actual process Value readings returned Good, non-null numeric Double data; no Good_NoData values were accepted. Existing discovery records corroborate every exact URI-based NodeId and process-Value description. Current U02 engineering-unit property reads are retained, including the server's malformed degree-C text; no conversions were introduced.

## Scope and execution

Fresh protected native backups, full provider exports and TBMC project exports were captured before and after changes. Baseline right-twin typeId is 5L_BIOREACTOR at the expected existing path. Previous 06A/06A.1 evidence, customer mapping, discovered nodes, live-data CSV, simulation code and rollback procedures were reviewed. The native tag import endpoint's documented MergeOverwrite operation applied 15 existing member patches: HTTP 200, successCount 15, failureCount 0. No project was added, edited or deployed. The left integration required no restoration.

Exactly 40 right-twin properties changed: 24 opcServer/opcItemPath values, 15 enabled flags, and STIRR memory → opc. Every original effective value is in 02_Approved_Change_Set.json. Both administrative EquipIsEnabled members were already enabled, Boolean True, and displayed 1; neither was written. Existing KeyCPP1/2/3 remain AFOAMT/BASET/TEMP on the right and pH/pO2/TEMP on the left. CO2SP, AIRSP, N2SP and O2SP are unchanged.

Live parameters: TEMP, pH, pO2, AFOAMT, BASET, SUBS_A, SUBS_B, SUBS_C, VWEIGHT, JTEMP, AIROV and STIRR. The first 11 already used OPC source mode; STIRR used a memory literal. Existing SIM controls remain unchecked, and selected detail inputs are disabled/read-only. Reviewed simulation code is interactive; shared timers and existing resources remain unchanged. No shared simulation logic was disabled and no equipment status or communication-quality flag was forced.

## End-to-end and screen evidence

03_U02_OPC_Verification.csv contains all right-twin node, value, type, unit, timestamp and eligibility records. 04_End_to_End_Verification.csv contains 24 comparisons across both vessels. Every recorded UDT value exactly matches a bracketing direct Double value converted to the existing Float4 type, and every detail display matches that UDT value at its original two-decimal precision. Read, UDT observation and display timestamps are separate; this is not a claim of atomic reads. Static values were accepted when quality and source identity were valid. Later changes in TEMP/pH demonstrate source refresh without starting equipment.

Both vessels' 24 UDT process qualities were Good at two observations 62.364 seconds apart; additional direct source observations span several minutes. Both overview source badges are “Source quality good”, using the unchanged transform that reads all three CPP references. Existing detail gauges, images and navigation were viewed. Existing TEMP ranges and differing raw process values are preserved, not corrected or certified appropriate. Gauge precision differs from the numeric readout by its existing display design.

Final simultaneous overview captured 2026-11-25T20:36:32.049Z (UTC; add 8 hours for Taipei):

![Both vessels live](06_SCADA_Evidence/overview-final-both-live.png)

[Left detail](06_SCADA_Evidence/detail-BRX5-02-01.png) · [Right detail](06_SCADA_Evidence/detail-BRX5-02-02.png) · [MFCS connected](06_SCADA_Evidence/mfcs-connection-final.png). The individual parameter and EquipIsEnabled screenshots provide all detail readings and final monitoring enablement evidence. Hidden application DOM includes a generic “No Connection to Gateway” overlay string; the actual rendered screens, native connection status and Good data were used to establish connectivity.

## Preservation and restrictions

05_Configuration_Diff.json proves the same 1839 provider nodes, all 494 TBMC resource files unchanged, all existing projects unchanged, no additional projects, parent UDT definitions unchanged, no changes to left-twin effective configuration, and no unauthorized effective property differences. Alarms/thresholds, status expressions, history, security, units, data types, tag groups, equipment hierarchy, graphics/bindings, images/colors, other equipment, and UNICORN configuration remain unchanged. Active/InUse/Batch flags remain disabled; monitoring does not imply a running or batch-associated vessel. No process Write request, setpoint modification, control command, forced alarm, certificate/authentication change or Gateway restart occurred.

All selected histories and applicable alarm definitions remain disabled. No notification, alarm-save, historian-write or equipment command function was invoked. Alarm firing and historian recording were not functionally tested. AC-15 is NOT TESTED for an independent audit of downstream notification delivery and database records; preservation of disabled configuration is separately verified. The other 19 scoped criteria pass; see Acceptance_Criteria.csv. This is not a formal SAT release or a full safety validation of every operator-accessible control.

## Recovery and inheritance qualification

Native backup stored tag-definition files differ from the active native provider export and do not include these live source addresses; prior U01 addresses were already absent from that stored representation. Fresh native provider exports were retained separately in protected before/after directories. Archive CRC integrity passes, but no complete restore, Gateway restart, filesystem scan or persistence recovery test was permitted/performed. Do not use the stored filesystem tag-definition files as a verified current local/inherited property classification. Their archival copies and the explicit qualification are included; active original override classification was not independently confirmed. The effective native before/after comparison does prove that only authorized source/enable properties changed and that parent definitions/typeId/hierarchy are unchanged. Manual rollback restores original effective properties; exact inheritance cleanup requires Designer review of the original provenance. See evidence/backup-runtime-qualification.json and 07_Rollback/.

## Final disposition and engineering items

Last direct read: 2026-11-25T20:36:33.122Z. Ignition trial active, 4335 seconds remaining at that observation; Kymera InfluxDB Module 2.83.2 ACTIVE / Trial. No trial reset, module toggle or license change was performed. TBMC_COM06A_PilotGuard_0224 remains absent; no new guard was installed. Both vessels are left enabled/live with correct distinct U01/U02 addresses. Temporary quality loss or trial expiry is to be reflected by the existing logic while live addressing and monitoring enablement remain configured; no automatic simulation substitution or rollback exists.

Outstanding engineering review: permanent licensing; backup/runtime representation and restart/restore durability; exact original override provenance; malformed temperature-unit metadata; existing gauge/range/alarm engineering suitability; excluded setpoint reconciliation; independent physical asset witnessing; historian acceptance and functional alarm/notification testing under separate authority. Recommended next work is to resolve recovery/licensing and those engineering items before formal SAT acceptance. Do not correct them by modifying this approved application during this commission.
