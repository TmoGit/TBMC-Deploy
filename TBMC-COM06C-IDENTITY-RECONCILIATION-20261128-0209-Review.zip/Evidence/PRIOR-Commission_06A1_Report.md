# Commission 06A.1 — BRX5-02-01 live monitoring

Completed controlled commissioning on 26 November 2026, Asia/Taipei. BRX5-02-01 is left enabled for live acquisition from MFCS_OPCUA U01 / Biostat B TWIN_L_814. Final measured snapshot: 2026-11-26T04:03:10.729+08:00; source CONNECTED, all 12 direct OPC and UDT values Good, and all three existing overview references Good. Administrative EquipIsEnabled was already True, enabled and Good, and required no write.

## Previous disabled indication

The prior TBMC_COM06A_PilotGuard_0224 log records a successful baseline rollback at 03:27:49.023 +08 after all 15 acquired/reference members lost good quality around trial expiry. It reports no source-property drift and all rollback configuration results Good. This restored the original disabled members. The existing overview transform labels the card “Unavailable / disabled” whenever its CPP references are not all good. It does not derive that text from the administrative EquipIsEnabled value. See evidence/prior-guard-status.json, before-runtime.json, and availability-logic-extract.json.

## Execution and disposition

The old rollback project was deleted through the authenticated native project API; its original evidence and manual rollback payload were retained. The temporary execution project was also deleted after verification. No replacement guard or automatic trial-reset task was deployed. The trial was already active before execution; no reset was performed. The final trial snapshot at 04:05:33 +08 was active with 6195 seconds remaining. These are timestamped observations, not a guarantee of future trial availability.

Restored exactly 40 previously approved properties: 24 OPC server/item addresses for 12 measurements, 15 member enable flags (12 measurements and KeyCPP1/2/3), and STIRR memory-to-OPC valueSource. KeyCPP1 remains pH, KeyCPP2 pO2, and KeyCPP3 TEMP. CO2SP, AIRSP, N2SP and O2SP are unchanged. Four acquisition samples over 60 seconds passed. See evidence/execution.json and Configuration_Diff.json.

Live addressing and enabled flags remain in place at completion and will remain configured if trial or communication fails; the existing quality and availability logic will show the interruption. No automatic simulation fallback or rollback remains.

## Values and screens

All 12 direct Double readings match existing UDT Float4 values after the original Float4 conversion; all 12 captured detail values match the existing two-decimal display precision. Separate read/capture timestamps are retained in Live_OPC_UDT_Display_Comparison.csv. Overview pH=12.08, pO2=-0.17 and TEMP=19.31, with “Source quality good”. These are actual source readings, without substituting expected process ranges.

![Existing Plasmid-814 overview](overview.png)

![Existing BRX5-02-01 detail](equipment-detail.png)

The twelve evidence/final-detail-*.png files document every parameter. The detail fields were read-only; no setup, control, alarm-save or simulation toggles were used.

## Preservation and limits

Fresh full native exports prove the same 1839 provider nodes and all 494 TBMC project resource files unchanged except the exact 40 approved tag properties. Parent UDTs, hierarchy, graphics, bindings, image/color selection logic, other equipment, alarms, thresholds, history and permissions are unchanged. EquipIsActive, EquipInUse and EquipBatchAquired remain Bad_Disabled; none was forced. Existing background #D5D5D5 and Twin_5L image remain governed by original logic. Monitoring is enabled; equipment running/batch status is not asserted.

Raw UA AccessLevel/UserAccessLevel checks confirm read-only access for all 12 nodes. Commission scripts used reads and tag configuration only, with no OPC process writes or server method calls. No alarms were forced and historian recording remains disabled for these tags. This verifies the scoped display/acquisition change; it does not certify a full FAT/SAT, historian operation, alarm firing or independent physical instrument calibration.

Supported native Gateway backups and native project/provider exports before and after the change are protected locally; their hashes and archive CRC checks are included. No complete backup restore was performed. Manual rollback instructions and the original targeted payload are in manual-rollback/. The upload package contains evidence, not an automatic deployment/import package.
