# Cleanup and resume — DEVELOPMENT, human review PENDING

Current run: TBMC-SAT-20261123-234928. Live Phase B remains DEFERRED. No application repair, approved business-rule change, schema migration, live connection/source mapping, physical command or production synthetic Influx history was performed.

## Removed owned resources

- Projects `TBMC_SAT_234928`, `TBMC_SAT_AlarmFinal_234928`, `TBMC_SAT_CacheValidation_234928` removed through supported authenticated native APIs.
- Journals `TBMC_SAT_Journal_234928` and `TBMC_SAT_JournalFinal_234928` removed. Memory roots `__TBMC_SAT_234928` and `__TBMC_SAT_AlarmFinal_234928` deleted with Good results.
- Four owned SAT_UI_234928 runtime UDTs deleted after protected exports; zero outstanding owned claims.
- Four SAT_CACHE_234928 relational-cache fixtures deleted after actual interval filtering test. All six non-test table row counts/hashes unchanged across that final group.
- No disposable Influx bucket/token/historian was created: provisioning denied HTTP401. No production token widened or replaced.
- Temporary schema-scoped database client option file removed. Browser sessions closed separately in `evidence/browser-closeout.json`; protected profiles retained, no unrelated browser terminated.

## Retained evidence and state

Three owned reusable SQL setups retained: `SAT_234928`, `SAT_UI_234928` (setup330, edited age31) and `SAT_DB_FINAL_234928` (age4). Released synthetic claims, actual workflow/control audit and synthetic alarm journal SQL events retained. No audit repair, broad test-row deletion or pruning. Empty-equipment UI runs produced no owned reporting cache. Direct interval cache fixtures were temporary tests, not app-generated cache/history proof.

`evidence/native-first-cleanup.json`, `native-final-and-cleanup.json`, `gateway-resource-cleanup.json`, `alarm-final-resource-cleanup.json`, `cache-project-cleanup.json` and `cache-input-validation.json` contain actual cleanup observations. Final `preservation-verification.json` shows preexisting default tag configurations exactly equal, all 494 TBMC project entries unchanged and seven recorded connection configurations unchanged. Native column/key fingerprint unchanged; this is not a proof of every possible database object or all whole-run non-test rows.

## Protected recovery references

Protected nonsynchronized directory is recorded in `protected-storage-location.txt`, outside this report and Git. It contains fresh native `pre-investigation.gwbk`, `pre-investigation-TBMC.zip`, provider exports, `pretest-app-ignition_config.sql`, protected owned-tag evidence and final native exports. Do not distribute these exports: they may contain credentials.

Gateway backup: 34,687,558 bytes, SHA256 `5e37ce6d142c10943d7d901c0338a490b94eb0f51fce2541a01f2fb48037be48`; CRC valid, 5507 entries. SQL dump: 1,313,059,602 bytes, SHA256 `4609cab2015ceea5f8ab0b2cce8e56a9f10ca30ab27147b9d7808a57ea43e060`, exit0. Earlier stale credential client dump exit2/zero bytes is a failed attempt, never a recovery artifact. No administrator/default account was newly enabled by this SAT run.

For restoration verification, provide an isolated compatible Ignition8.3.4 host with outbound equipment interfaces disabled; use the supported Gateway restore facility and a separate isolated SQL schema, then reconcile protected object manifests. Do not restore the live Gateway to test a backup. No isolated restore host was available (DEF-017).

## Exact resumption inputs

1. Acropolis technical review of Abort-to-Complete, overwritten audit run UID, omitted PDF run ID, pointer overlay and detail quality display. Baseline testing does not authorize repairs. Any separately authorized repair must preserve this run and append retests.
2. TBMC database administrator supplies dedicated test bucket/token and correlates current authorization scopes. Then Acropolis can test actual Kymera samples and isolated recovery without production history.
3. TBMC provides approved source exports, physical inventory/CPP/alarm/transition/security/event policies and representative User/Entra identities. Acropolis defines safe shared-equipment and failure-injection fixtures, then completes blocked UI/backend/report cases.
4. TBMC vendor/site provides selected MFCS tunnel product, both endpoints/services/licenses/ports/interface and MFCS-local DA inventory; provides actual UNICORN PC/service/version/UA endpoint and entitlement. See OPC supplement. No guessed ports or silent boundary expansion.
5. TBMC explicitly releases Phase B; prove intended MFCS and UNICORN paths separately, approved mapping/quality/history and witnessed local alarms. TBMC performs all physical actions.
6. TBMC supplies permanent licenses, infrastructure/time/hardening/restore readiness, named handoff owners and human verification/acceptance. All signatures and due dates stay blank until actual agreement.

No work is accepted or production ready. All technical records remain PENDING human review. Existing prior historian authorization cleanup ID11a6853a38108000 needs owner disposition; this historical item was not newly created or automatically revoked.
