# OPC discovery — read-only, development

Current run TBMC-SAT-20261123-234928; actual six-host observations in [OPC-DISCOVERY.csv](OPC-DISCOVERY.csv). This records discovery, not live integration.

| Target | Role / intended route | Current result |
|---|---|---|
| 172.16.81.10 | Room801 MFCS host, DA through selected tunnel | Echo reply; tunnel product/interface/listener not evidenced |
| .13 / .14 | Sartorius controllers through MFCS .10 | Echo replies; no DA/UA listener required on controllers |
| .20 / .68 | Cytiva instrument addresses, actual UNICORN host unknown | Echo replies; do not assume these are UNICORN PCs |
| .37 | Cytiva instrument address, actual UNICORN host unknown | No ICMP echo after one retry; no service absence conclusion |

Installed Matrikon OPC Explorer5.4.1.0 and installed version-matched manual support Classic DA/A&E/COM/DCOM. Neighborhood is not UA inventory; no undocumented CLI invoked. No selected OPC tunnel identified in local software/services/configuration. Windows SSTP VPN service is unrelated evidence. Remote deployment state remains UNKNOWN. Existing enabled MFCS Classic test connection is FAULTED, host text fullwidth, blank ProgID/CLSID; unchanged and root cause unproven.

No configured tunnel listener port or confirmed UNICORN UA endpoint was found. Therefore no TCP scan/135/4840/62541 guesses, remote OPCEnum requirement, FindServers/GetEndpoints against assumed hosts, process subscription, new equipment connection, certificate trust, firewall/DCOM change or installation occurred. Discovery limits were two concurrent checks maximum, two-second timeout and one retry; only bounded ICMP was applicable. Local DA registration requires a separate authorized MFCS-host session (BLOCKED).

[OPC-SUPPLEMENTAL-TARGETS.csv](OPC-SUPPLEMENTAL-TARGETS.csv) lists .65 Room815 MFCS outside the authorized six-host boundary and unknown UNICORN host/port records. Missing values remain UNKNOWN: TBMC/vendor must provide actual host, selected product, both service identities/versions/licenses, configured transport/UA endpoint and equipment mapping before a precise new authorized check can run. No host/port invented to make a scan list.

Owners follow supplied RM: TBMC site/vendor/access prerequisites; Acropolis configuration after approval/release; joint live verification. DEF-020 through024 separate unknown tunnel, unknown UA server, existing connection fault, reachability and missing local access. .37 is not labeled equipment failure. Source architecture identifies .10/.65 MFCS hosts, not tunnel/UA deployment.

After explicit Phase B release, SAT-027 must prove MFCS tunnel and UNICORN UA separately. SAT-028 through030 then prove approved mapping, quality/time, historian flow and witnessed alarms. Discovery cannot pass these live criteria.
