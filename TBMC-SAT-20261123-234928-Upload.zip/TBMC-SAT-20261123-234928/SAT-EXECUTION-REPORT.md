# Acropolis TBMC development SAT execution report

Run **TBMC-SAT-20261123-234928**. Review **PENDING**. **Not accepted or production ready.** Controlled SAT-TBMC-001 Rev02: 33 tests, 99 numbered TC/AC steps. No automated signature, acceptance or waiver. Human tester/verifier fields are blank in [result sheets](SAT-RESULT-SHEETS.html).

All available safe groups have been executed or explicitly assigned an actual dependency. Phase B stays DEFERRED by user boundary. Final technical outcomes are calculated from the latest row per criterion: **{'PASS': 40, 'BLOCKED': 36, 'FAIL': 11, 'DEFERRED': 12}**. Original attempts: **{'PASS': 37, 'BLOCKED': 40, 'FAIL': 10, 'DEFERRED': 12}**. 108 total rows retain every original slot and subsequent evidence corrections/retests. A technical PASS applies only to the scope stated in its actual-result field and remains unreviewed.

## Environment and authority

Actual host TP-IGN01, Gateway/project `http://172.16.81.201:8088` / TBMC, Ignition8.3.4 b2026030309; source172.16.81.201, route next-hop172.16.81.254; MariaDB10.11.11 local ignition_config through ignitionDB; historian10.1.0.132:8086 InfluxDB2.8.0 / TBMC-Sensor-Data. Windows Asia/Taipei UTC+08:00; run crosses midnight 23–24November2026. Per-step recording timestamps and timestamped evidence are retained separately: recording time is not necessarily execution time.

Gateway administrator native Access/Read/Write were verified separately from Windows privilege. Windows token was not elevated; no privileged OS administration was required or attempted repeatedly. Existing protected credentials were used without publication. This SAT did not repeat the earlier administrator reset. Effective Gateway privileges, not OS elevation, authorized isolated native configuration. No UAC action needed.

User instruction authorizes execution through actual barriers and retains Rev02 as controlled source. Attached specifications/commission are scope and criteria references, not independent permission to repair, sign, expand live access or send external messages. Formal approval/qualified witness unavailable, so DEVELOPMENT mode applies. No application repair, schema migration or process source/writeback performed.

## Controlled sources and coverage

- [Unchanged Rev02 DOCX](controlled-source/TBMC_SAT_Protocol_Rev02.docx), SHA256 `585540da5b3bf6f6fc16bb9f1c8c4bf1120844f452a199b1a8b851996591e25a`. DOCX paragraphs/tables parsed in order using accepted revision content; deleted/move-from content excluded. All five-column result/signature source cells blank. Human-readable exact tables reproduced in result sheets. No native Word/LibreOffice renderer available; HTML transcription review is not a native pagination validation.
- DDS2.1 Final Controlled Revision; SHA256 `ff61e05a795375a08bd44dd1525b439195914c7cc6c8d509b6d29ba57ea3f53a`.
- FAT RPT-25010-2 Rev02 with CO addendum; SHA256 `823b64a7f79e3df868dd63c563d8afff348592c9c71f6823fb7d90bd90e5fcec`.
- RM Rev0 21August2026; SHA256 `c6624c8b194d12801b7399758ee9f5d7255ece962df3b5b348831f45b3c6dd55`.
- Architecture RevC/equipment workbook and fresh native exports reconciled; 31 workbook rows, 40 non-runtime instances (35 equipment/five server), 30 candidate mappings and 13 explicit exceptions. No guessed room/twin/source approval.

[Coverage](SAT-COVERAGE.csv) contains all53 FAT/CO criteria (12 original,41 CO) plus25 RM areas. Semantic SAT links are checked against actual controlled Rev02 topics; approval remains pending. Historical FAT PASS/N/A/signatures are not current SAT outcomes. FAT-001 TC1 FAIL remains open DEF-002; two CO card-ID N/A records need current source reconciliation DEF-019. Rev00 remained reference only. Previous preflight run is linked separately and not reused as new execution.

## Latest technical results

| Stage | Steps | PASS | FAIL | BLOCKED | DEFERRED | NOT RUN |
|---|---:|---:|---:|---:|---:|---:|
| A | 78 | 37 | 10 | 31 | 0 | 0 |
| B | 12 | 0 | 0 | 0 | 12 | 0 |
| C | 6 | 1 | 1 | 4 | 0 | 0 |
| D | 3 | 2 | 0 | 1 | 0 | 0 |

| Test | Stage | Step1 | Step2 | Step3 | Latest linked deficiencies |
|---|---|---|---|---|---|
| SAT-001 | A | PASS | PASS | BLOCKED | DEF-001 |
| SAT-002 | A | PASS | PASS | BLOCKED | DEF-002 |
| SAT-003 | A | BLOCKED | BLOCKED | PASS | DEF-003; DEF-004 |
| SAT-004 | A | PASS | PASS | BLOCKED | DEF-005 |
| SAT-005 | A | PASS | BLOCKED | PASS | DEF-006 |
| SAT-006 | A | PASS | PASS | FAIL | DEF-027 |
| SAT-007 | A | BLOCKED | BLOCKED | PASS | DEF-006; DEF-007; DEF-014 |
| SAT-008 | A | PASS | BLOCKED | BLOCKED | DEF-003; DEF-026 |
| SAT-009 | A | PASS | PASS | BLOCKED | DEF-004; DEF-006 |
| SAT-010 | A | BLOCKED | BLOCKED | PASS | DEF-008 |
| SAT-011 | A | BLOCKED | BLOCKED | BLOCKED | DEF-008; DEF-009 |
| SAT-012 | A | PASS | PASS | PASS |  |
| SAT-013 | A | PASS | FAIL | FAIL | DEF-014; DEF-018 |
| SAT-014 | A | BLOCKED | BLOCKED | BLOCKED | DEF-018 |
| SAT-015 | A | PASS | FAIL | BLOCKED | DEF-012; DEF-013; DEF-016 |
| SAT-016 | A | PASS | PASS | BLOCKED | DEF-008; DEF-018 |
| SAT-017 | A | BLOCKED | BLOCKED | PASS | DEF-006; DEF-007 |
| SAT-018 | A | PASS | BLOCKED | PASS | DEF-011 |
| SAT-019 | A | BLOCKED | FAIL | PASS | DEF-008; DEF-015; DEF-019 |
| SAT-020 | A | FAIL | PASS | BLOCKED | DEF-008; DEF-011; DEF-015; DEF-018 |
| SAT-021 | A | FAIL | BLOCKED | FAIL | DEF-006; DEF-007; DEF-012; DEF-027 |
| SAT-022 | A | BLOCKED | PASS | PASS | DEF-011 |
| SAT-023 | A | PASS | PASS | PASS |  |
| SAT-024 | A | FAIL | BLOCKED | PASS | DEF-010; DEF-011 |
| SAT-025 | A | FAIL | BLOCKED | PASS | DEF-011; DEF-013; DEF-014; DEF-016 |
| SAT-026 | A | PASS | BLOCKED | PASS | DEF-003; DEF-005; DEF-017 |
| SAT-027 | B | DEFERRED | DEFERRED | DEFERRED | DEF-004 |
| SAT-028 | B | DEFERRED | DEFERRED | DEFERRED | DEF-004 |
| SAT-029 | B | DEFERRED | DEFERRED | DEFERRED | DEF-004 |
| SAT-030 | B | DEFERRED | DEFERRED | DEFERRED | DEF-004 |
| SAT-031 | C | FAIL | BLOCKED | BLOCKED | DEF-002; DEF-003; DEF-005; DEF-009 |
| SAT-032 | C | PASS | BLOCKED | BLOCKED | DEF-001 |
| SAT-033 | D | PASS | BLOCKED | PASS | DEF-020; DEF-021; DEF-022; DEF-023; DEF-024 |

## Observed failures and impact

The actual ABORT confirmation completed the owned batch and logged COMPLETE (DEF-013, High provisional). First-run LOAD audit UID was rewritten to the second run of the same saved setup (DEF-014, High). Both correctly supplied same-name report PDFs omitted explicit run IDs (DEF-015, High). These failures undermine terminal semantics and traceability and require Acropolis correction under a separate repair scope.

Gauge SVG blocked pointer access to HOLD/ABORT controls; normal keyboard focus/Space allowed testing to continue (DEF-012, Medium). Public Main required login contrary to the DDS role matrix, with conflicting overview prose requiring policy review (DEF-010, provisional). A representative unavailable BRX5 detail showed unqualified numeric50 indicators (DEF-027, provisional); their precise intent/cause is not proven and they are not claimed as real healthy process data. Permanent production licensing failed; current trial operation does not close FAT-001 (DEF-002).

No code/configuration repair was made to improve results. Read-only source inspection followed observed failures and supports, but does not replace, runtime evidence.

## Completed evidence and limits

Native Gateway login, fresh protected backups, archive CRC, current schema-scoped SQL dump, actual versions, fresh inventories and SQL Named Queries were exercised. Real UI save/edit/two-load cycles maintained setup identity and created unique runtime UDTs. Actual UI Start/Hold, Complete, Abort and Archive cases were observed only on empty-equipment owned batches. Held state persisted across refresh and a second session. Backend claim component tests exercised first-owner/conflict/idempotence/release, but do not pass the full shared-equipment UI criteria, which stay BLOCKED.

Four isolated memory alarm scenarios generated active/ack/clear events; final20 journal events and eight associated SQL actor properties establish backend trace. Real role-based alarm authorization remains BLOCKED. Corrected report inputs use the actual Reports transform; two PDFs/all four pages were rendered and visually reviewed. Native Gateway export is not User-role GUI export proof. First empty-input PDFs and intermediate incomplete journal actor attempts remain preserved as harness/prerequisite limitations, not application failures.

An actual uninterrupted15-minute idle interval ended with logout. Exact transition instant was not polled, so no precise15:00 measurement is claimed. Protected navigation required login and normal reauthentication succeeded. Native logout and one invalid nonexistent-user login were tested. No Entra or missing User-role equivalence inferred.

Disposable Influx provisioning failed HTTP401; no synthetic production writes and no new bucket/token. Existing historian RUNNING/healthy does not prove new Kymera samples, buffering/recovery or full live mapping. Current authorization scope not correlated: initial SAT008/2 PASS is explicitly superseded by BLOCKED, preserving original history. SAT009/2 original mistyped evidence reference is documented with a correction artifact and a later valid observation.

Final interval test inserted four explicit temporary relational cache fixtures (not historian or normal application-generated cache proof). Actual Named Query and Reports UI excluded null/zero/negative intervals and showed valid only, then deleted all four. Six non-test SQL tables had equal counts/hashes across that final group. The UI capture's runtimeExceptions field was a harness constant and is excluded from measured-error conclusions; earlier navigation counters were measured. Empty-equipment UI runs produced no owned cache rows, so end-to-end normal cache/export remains blocked.

Phase D refreshed only six authorized hosts: five echo replies, .37 no echo after retry. No selected tunnel ports or confirmed UNICORN UA host/endpoint exist in available configuration, so no guessed listener scan or UA metadata calls. .13/.14 are controllers through MFCS, not expected OPC servers. .65 and unknown UNICORN hosts are supplemental pending targets. Matrikon Classic DA/A&E capabilities verified; Neighborhood is not UA inventory. See [discovery](OPC-DISCOVERY.md).

## Outstanding items and prioritized ownership

All27 outstanding items are in [SAT-DEFICIENCIES.csv](SAT-DEFICIENCIES.csv), including dependencies/deferrals and historical follow-up; severity provisional, due dates blank, owner acceptance not recorded. DEF IDs are scoped by this run and are not identities inherited from prior run numbering.

1. Acropolis reviews terminal action, audit identity and report identity failures, then pointer/quality presentation findings. Any repairs need separate authorized scope and preserved baseline/retest evidence.
2. TBMC DB administrator provisions isolated test storage and verifies integration authorization. TBMC process/security supplies approved mapping/CPP/alarm/transition/event policies and real User/Entra representatives; Acropolis completes safe fixture-dependent testing.
3. TBMC/vendor supplies actual MFCS tunnel and UNICORN server/service/license/endpoint details, authorized local DA inventory and explicit Phase B release. Joint witnessed verification follows release.
4. TBMC procures permanent entitlements, completes infrastructure/time/hardening/isolated-restore readiness, names operational owners and performs human review/acceptance. No automatic waiver or acceptance.

## Cleanup and deliverables

[Cleanup and resume](CLEANUP-AND-RESUME.md) lists removed resources, retained SQL evidence and protected recovery references. Fresh final comparisons show default tag export exactly equal, all494 TBMC project entries and seven connection configurations unchanged. Column/key schema fingerprint unchanged; no blanket proof of every DB object or every non-test row across the whole run. Test projects/journals/memory/runtime UDTs removed, no owned active claims; temporary DB client file removed. Protected profiles remain private; browser closure verified separately.

- [Step results with all attempts](SAT-STEP-RESULTS.csv)
- [Exact result sheets with blank human signatures](SAT-RESULT-SHEETS.html)
- [Deficiencies](SAT-DEFICIENCIES.csv) and [FAT/RM coverage](SAT-COVERAGE.csv)
- [Evidence index with actual file hashes](EVIDENCE-INDEX.csv)
- [OPC inventory](OPC-DISCOVERY.csv) and [pending supplemental targets](OPC-SUPPLEMENTAL-TARGETS.csv)

Credential-bearing backups and raw exports remain outside this package in protected nonsynchronized storage. No Git push, external publication or message sent. Final automated package validation and browser closeout appear in evidence; human review and acceptance remain PENDING.


## Outstanding-item overview

| ID | Provisional severity | Type | Owner action |
|---|---|---|---|
| DEF-001 | High (provisional) | acceptance item | TBMC acceptance; Acropolis qualified execution arrangements: Arrange named personnel, review evidence and sign only actual disposition. |
| DEF-002 | High (provisional) | acceptance item | TBMC procurement; Acropolis activation after provision: Provide purchased required entitlements and activate through supported controls. |
| DEF-003 | High (provisional) | requirement gap | TBMC infrastructure/security; Acropolis document actual configuration: Approve final build, services, historian endpoint/retention/security and operating baseline. |
| DEF-004 | High (provisional) | deferred live verification | TBMC site/vendor readiness and release; Acropolis integration after release; joint witness: Supply explicit site release and approved equipment/source/CPP references. |
| DEF-005 | Medium (provisional) | acceptance item | TBMC operations owner; Acropolis handoff support: Name operations/support owners and complete independent administration/recovery handoff. |
| DEF-006 | High (provisional) | requirement gap | TBMC equipment/source approvals; Acropolis comparison after approval: Provide approved source exports and resolve listed equipment/server/room/twin exceptions. |
| DEF-007 | High (provisional) | requirement gap | TBMC process owner; Acropolis binding review after approval: Issue approved per-device CPP and alarm register. |
| DEF-008 | High (provisional) | infrastructure dependency | TBMC database administrator; Acropolis isolated historian configuration: Provision dedicated short-retention test bucket and least-privilege test token privately; do not widen production credential. |
| DEF-009 | Medium (provisional) | requirement gap | TBMC infrastructure/process: Approve time source, timezone convention and permitted skew. |
| DEF-010 | Medium (provisional) | application defect | Acropolis application; TBMC policy clarification: Resolve source wording then align approved Main access policy under separate repair scope. |
| DEF-011 | High (provisional) | requirement gap | TBMC identity/security/process; Acropolis role configuration after decisions: Provide approved identity/group mapping, representative accounts and complete role/action/audit policy. |
| DEF-012 | Medium (provisional) | application defect | Acropolis application: Correct layout/hit testing under separately authorized repair; retain baseline evidence. |
| DEF-013 | High (provisional) | application defect | Acropolis application: Correct abort terminal action/state/audit and release handling under separate repair scope. |
| DEF-014 | High (provisional) | application defect | Acropolis application: Restrict audit identity updates to immutable per-run target under separate repair; retain original evidence. |
| DEF-015 | High (provisional) | application defect | Acropolis application: Bind visible explicit run identity and verify report inputs/layout under separate repair scope. |
| DEF-016 | Medium (provisional) | requirement gap | TBMC process/security; Acropolis specification reconciliation: Approve explicit allowed/rejected transition and required audit matrix. |
| DEF-017 | High (provisional) | execution limitation | TBMC infrastructure; Acropolis restore verification: Provide isolated compatible Gateway with outgoing equipment interfaces disabled. |
| DEF-018 | Medium (provisional) | execution limitation | Acropolis fixture design; TBMC approved process and isolated endpoints: Define safe UI-compatible synthetic fixture and isolated dependency endpoints, with no physical source/writeback. |
| DEF-019 | Medium (provisional) | requirement gap | TBMC process approval; Acropolis source reconciliation: Approve explicit source reconciliation and card/run-ID presentation decisions; no historical N/A inherited. |
| DEF-020 | High (provisional) | infrastructure dependency | TBMC site/vendor; Acropolis integration after prerequisites: Provide selected product deployment/configuration, both endpoints and actual transport ports. |
| DEF-021 | High (provisional) | requirement gap | TBMC Cytiva/vendor and site: Provide equipment-to-server map and version-matched UA service/entitlement/endpoint evidence. |
| DEF-022 | Medium (provisional) | infrastructure dependency | TBMC vendor prerequisites; Acropolis configuration after approved design/release: Determine selected tunnel design and retire/correct legacy test connection only under separate approved scope. |
| DEF-023 | Medium (provisional) | infrastructure dependency | TBMC site networking/vendor: Confirm host role, power/network and ICMP policy using site procedures. |
| DEF-024 | Medium (provisional) | execution limitation | TBMC site/vendor access: Provide authorized MFCS-local operator/session and installed component inventory. |
| DEF-025 | Medium (provisional) | acceptance item | TBMC database administrator; prior commission owner: Privately inspect historical authorization ownership/use and record approved retain/revoke disposition. |
| DEF-026 | Medium (provisional) | execution limitation | TBMC database administrator: Correlate integration credential with approved authorization definition and sanitized least-privilege scopes. |
| DEF-027 | Medium (provisional) | application defect | Acropolis application; TBMC process review: Confirm indicator intent and quality/status bindings, then correct misleading presentation under separate repair scope. |
