﻿# Kymera database correction complete - gateway acceptance pending

Date: 2026-11-17 UTC. Database-side correction validated at 2026-11-17T15:19:32.8055700Z.

## Review finding

The supplied verified report correctly distinguishes a valid bucket-data token from a working Kymera historian connection. Ignition 8.3.4 (b2026030309) is shown in its captured gateway page. The native Flux query passed, but the module's UsersApi.me initialization failed with read:users/11a58fc791889000 unauthorized. Organization metadata was also denied. Existing historian InfluxDB was intentionally left disabled, with corrected private URL and encrypted old credential retained; queues were reported empty. Exact installed Kymera version is not captured in the reviewed evidence.

Earlier DB-side validation proved bucket permissions but missed Kymera identity-metadata initialization. The new gateway evidence identified the necessary additional scope. No all-access or bucket-provisioning privilege is needed for the production connection.

## Correction performed and verified

- Reproduced old token behavior: user and org metadata HTTP 401; production bucket metadata HTTP 200.
- Independently verified token-owning user ID with the protected operator credential.
- Created dedicated replacement production authorization 11a6853a21d08000: read/write only bucket 7dac3900b1b2323d, orgID 0d928763db22136b; read only user 11a58fc791889000; read only organization 0d928763db22136b. Exactly four permissions. No write users/orgs, bucket provisioning or authorization management.
- Production bucket TBMC-Sensor-Data and unlimited retention unchanged. Replacement token /api/v2/me, /api/v2/orgs/0d928763db22136b and production bucket metadata all returned HTTP 200. Nonmutating production Flux query passed.
- Old authorization 11a58fc7e4c89000 preserved pending replacement gateway acceptance. Existing reporting/admin authorizations untouched.
- Created disposable bucket TBMC-Commission-Kymera-20261117, ID ecedb062071ec18b, 24-hour retention (86400 seconds), and separate authorization 11a6853a38108000 scoped to its own bucket plus the same minimal user/org metadata reads.
- Disposable token metadata checks HTTP 200; test-only write HTTP 204 and exact readback value 42 passed. Test measurement db_commission_probe is separate from actual historian test data. No synthetic production writes.
- Cross-bucket isolation checked: production token cannot read test bucket metadata, and test token cannot read production bucket metadata; both HTTP 401. Definition checks also constrain both writes to their own bucket.
- Test bucket/token intentionally retained for actual isolated Ignition historian acceptance. Retention expiry does not delete the bucket or revoke its token.
- Service remains healthy v2.8.0 at http://10.1.0.132:8086. No service restart, database reset or network changes required for this correction.

## Corrected protected handoff - not part of this report

C:\Users\tpignclouduser\Desktop\TBMC-InfluxDB-Handoff\Ignition-InfluxDB-Connection-TEMP.txt

This file now contains BOTH clearly separated production and disposable-test credentials and exact resource IDs. Its restricted ACL was verified before and after update. Old plaintext handoff archived only in the established protected store for recovery, not in reports. Authoritative new tokens are under C:\Users\tpignclouduser\AppData\Local\TBMC\InfluxProduction\clients\ignition-kymera-production.token and ignition-kymera-commissioning.token. No administrator credential included. Never upload/email/render/commit the handoff or authoritative token files.

Previously transferred TP-IGN01 copies contain the OLD token and must be replaced by secure transfer. This session has not transferred secrets or modified the actual gateway.

## Exact next action on TP-IGN01

1. Securely transfer the corrected handoff to the established restricted nonsynchronized storage on TP-IGN01; restrict its ACL before writing. Replace the old handoff references; do not reuse the previous production token.
2. With the replacement PRODUCTION token, verify GET /api/v2/me, GET /api/v2/orgs/0d928763db22136b and GET /api/v2/buckets/7dac3900b1b2323d all return 200; perform a nonmutating Flux query. Never log token/response process values.
3. Inspect installed Kymera module version and current historian configuration through the supported gateway interface. Preserve backup/resource evidence already recorded under C:\TBMC\Secure\TBMC-InfluxDB-Verified-20261117-230023 on TP-IGN01. Do not restore/replay the entire gateway or reset its credentials.
4. Update only the existing historian named InfluxDB with URL http://10.1.0.132:8086/, organization TBMC, production bucket TBMC-Sensor-Data and Gateway-encrypted replacement PRODUCTION token. Preserve unrelated settings/mappings. Re-enable and confirm healthy/connected status rather than ERROR. Do not clear queues or restart the gateway unless an actual documented requirement arises.
5. Create a separate temporary historian using the DISPOSABLE test bucket/token. Configure only owned isolated memory tags and write known timestamped values through Ignition historization. Read them back using Ignition's historical query API, checking timestamps/value/quality and store-and-forward diagnostics. Direct HTTP write alone does not count. Do not point synthetic tags at production.
6. Remove owned test tags/provider/historian/project, then revoke ONLY test authorization 11a6853a38108000 and delete ONLY test bucket ecedb062071ec18b using the protected DB administrator session. Preserve unrelated resources. Record cleanup.
7. Retire the old production authorization only after replacement gateway acceptance and confirmation no other client uses it. Delete temporary and superseded handoff copies after secure transfer and successful validation, including the archived old handoff; keep authoritative production credential. Do not delete before completion.
8. Update the final acceptance report with actual gateway/module versions, healthy historian status, isolated historian write/query evidence and cleanup status. Production readiness remains pending those observations.

## Access limitation

A direct HTTP probe from this DB-side session to 172.16.81.201:8088 timed out after five seconds. No authenticated execution/control of TP-IGN01 is available here. This does not contradict successful TP-IGN01-to-DB connectivity and does not justify changing external routing/firewalls. Continue gateway work in the existing TP-IGN01 commissioning session with secure handoff.

## Recovery and reusable work

The previous production authorization and original token file remain active for rollback. Preserve the existing disabled gateway resource/backup; restore only the intended historian through supported controls if needed. Prepare-TBMC-Kymera-Credentials.ps1 in Desktop\TBMC-InfluxDB-Reports records the DB-side procedure, reuses existing matching new tokens, verifies exact scope, and never embeds credential values. Running it again performs a test-only probe; no production writes.

Historical PDF/HTML evidence in the supplied verified folder describes the pre-correction failure. This report and DB-SIDE-CORRECTION-RESULT.json are the current DB-side status; historian acceptance is still pending.

Official authorization reference: https://docs.influxdata.com/influxdb/v2/api/authorizations-api-tokens/
