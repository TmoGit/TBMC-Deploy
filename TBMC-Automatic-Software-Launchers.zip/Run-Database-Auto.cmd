@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tbmc-database.ps1"
echo.
echo TBMC launcher finished. Review the output above.
pause
