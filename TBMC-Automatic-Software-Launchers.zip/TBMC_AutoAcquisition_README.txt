TBMC one-click acquisition + deployment launchers (Windows Server)
=============================================================

THIS PACKAGE REPLACES THE PREVIOUS DESKTOP LAUNCHERS.
It does not replace the protected TBMC-Deploy GitHub repository.

On the client IGNITION server:
- Copy tbmc.ps1 to C:\tbmc.ps1, replacing the earlier copy, OR
- Put this ZIP's contents on the Desktop and double-click Run-Ignition-Auto.cmd.

On the client TIME-SERIES DATABASE server:
- Copy tbmc-database.ps1 to C:\tbmc-database.ps1, OR
- Put this ZIP's contents on the Desktop and double-click Run-Database-Auto.cmd.

These launchers:
1. Locate TBMC-Deploy-main on the Windows Desktop or reuse the staged
   C:\TBMC\TBMC-Deploy repository.
2. Preserve client.json, logs, and deployment state. Never overwrite a
   previously staged valid repository.
3. Check all role-specific software in one pass. Recognize MariaDB 10.11
   based on actual MSI metadata, not a fictional placeholder filename.
4. Reuse locally present version-matching packages.
5. Download missing packages from official / trusted release sources to
   C:\TBMC\Installers (requires outbound HTTPS from the Windows server).
6. Verify official published SHA-256 where available (e.g. MariaDB 10.11.19,
   InfluxDB CLI 2.8.0) and Authenticode signatures where available. Other
   archives are checked for format, downloaded over approved HTTPS, and
   SHA-256 pinned. This is NOT the same as independently publisher-verifying
   every archive. Downloaded checksums are written to the report.
7. Correct client.json installer filenames, URLs, SHA-256s, installation
   directory and exact source release versions. Make a timestamped backup.
8. Prepare age.exe automatically if missing and make it available for
   the current deployment session. Never generate or store private keys.
9. Run the repository orchestrator's -DryRun. When prerequisites pass,
   ask for explicit confirmation before a LIVE install/restore.

Downloaded software by role:
- Ignition: Ignition 8.3.4 build 2026030309 Windows x64 installer;
  MariaDB 10.11 Windows x64 MSI (uses existing 10.11 patch MSI if valid;
  otherwise 10.11.19); age CLI.
- Database: QuestDB 9.3.3 Windows bundled-runtime archive;
  InfluxDB OSS 2.8.0 Windows server ZIP; InfluxDB CLI 2.8.0 ZIP; age CLI.
- Captured proprietary Ignition modules, JDBC drivers, project archives,
  and credentials must come from the existing encrypted deployment artifacts.

Remaining real prerequisites that the launchers cannot invent:
- Age private key in C:\TBMC\Secure\deploy.key (your existing key).
- Valid destination settings/credentials in client.json and encrypted artifacts.
- Ignition / third-party module licenses and required entitlements.
- Remaining InfluxDB org/bucket/task metadata, if source not captured.
- Working internet or an offline installer directory containing the packages.
- Any other dependency named in client.json outside the supported set.

Important: These launchers are newly generated but NOT tested on the client's
Windows machines. They do not bypass version or artifact checks in the repo.
First confirm software download and -DryRun results. Do not approve LIVE
installation until destination network settings and backups are reviewed.

Report:
C:\TBMC\Logs\TBMC-Software-Readiness.json

Source download references:
https://inductiveautomation.com/downloads/archive/8.3.4
https://mariadb.com/downloads/
https://github.com/questdb/questdb/releases/tag/9.3.3
https://www.influxdata.com/downloads/
https://github.com/FiloSottile/age/releases
