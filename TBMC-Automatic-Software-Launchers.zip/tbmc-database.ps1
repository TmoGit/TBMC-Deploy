﻿#requires -Version 5.1
<#
.SYNOPSIS
 One-click, self-contained Database TBMC setup for an existing Windows Server.
.DESCRIPTION
 Run this script from the extracted TBMC-Deploy-main folder on the Windows Desktop.
 It discovers the folder, stages it at C:\TBMC\TBMC-Deploy, prepares support folders,
 copies a supplied client.json and/or age identity key if present on the Desktop,
 checks the underlying installation entry point, runs its dry run, and, after an
 explicit confirmation, launches the actual installer/restorer.

 No Proxmox access is needed. This cannot manufacture missing software packages,
 the age private key, client values, or the unknown Ignition version.
#>
[CmdletBinding()]
param(
    [string]$DestinationRoot = 'C:\TBMC',
    [switch]$DryRunOnly,
    [switch]$Resume
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$Role = 'Database'
$RelativeEntry = 'database\Install-Database.ps1'

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Right-click > Run with PowerShell also works when the user is not already elevated.
if (-not (Test-IsAdministrator)) {
    Write-Host 'Requesting administrator approval (Windows UAC)...' -ForegroundColor Yellow
    $ps = Join-Path $PSHOME 'powershell.exe'
    $launch = '-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '"'
    if ($DryRunOnly) { $launch += ' -DryRunOnly' }
    if ($Resume) { $launch += ' -Resume' }
    if ($DestinationRoot -ne 'C:\TBMC') { $launch += ' -DestinationRoot "' + $DestinationRoot + '"' }
    try {
        $proc = Start-Process -FilePath $ps -Verb RunAs -ArgumentList $launch -Wait -PassThru
        exit $proc.ExitCode
    }
    catch {
        Write-Host ('Administrator elevation was not approved: ' + $_.Exception.Message) -ForegroundColor Red
        exit 1
    }
}

function Test-TbmcRepository([string]$Candidate) {
    if ([string]::IsNullOrWhiteSpace($Candidate)) { return $false }
    if (-not (Test-Path -LiteralPath $Candidate -PathType Container)) { return $false }
    return ((Test-Path -LiteralPath (Join-Path $Candidate 'ignition\Install-Ignition.ps1') -PathType Leaf) -and
            (Test-Path -LiteralPath (Join-Path $Candidate 'database\Install-Database.ps1') -PathType Leaf))
}

function Get-DesktopFolders {
    $paths = New-Object 'System.Collections.Generic.List[string]'
    $paths.Add([Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory))
    if ($env:USERPROFILE) { $paths.Add((Join-Path $env:USERPROFILE 'Desktop')) }
    if ($env:PUBLIC) { $paths.Add((Join-Path $env:PUBLIC 'Desktop')) }
    if ($env:OneDrive) { $paths.Add((Join-Path $env:OneDrive 'Desktop')) }
    if ($env:OneDriveCommercial) { $paths.Add((Join-Path $env:OneDriveCommercial 'Desktop')) }
    return @($paths | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Container) } | Select-Object -Unique)
}

function Find-ExtractedRepository {
    $candidates = New-Object 'System.Collections.Generic.List[string]'
    $candidates.Add($PSScriptRoot)
    $candidates.Add((Join-Path $PSScriptRoot 'TBMC-Deploy-main'))
    $candidates.Add((Join-Path $PSScriptRoot 'TBMC-Deploy'))
    foreach ($desktop in @(Get-DesktopFolders)) {
        $candidates.Add((Join-Path $desktop 'TBMC-Deploy-main'))
        $candidates.Add((Join-Path $desktop 'TBMC-Deploy'))
        foreach ($dir in @(Get-ChildItem -LiteralPath $desktop -Directory -ErrorAction SilentlyContinue |
                     Where-Object { $_.Name -like 'TBMC-Deploy*' })) {
            $candidates.Add($dir.FullName)
        }
    }
    foreach ($candidate in @($candidates | Select-Object -Unique)) {
        if (Test-TbmcRepository $candidate) { return (Resolve-Path -LiteralPath $candidate).ProviderPath }
    }
    return $null
}

function Assert-PowerShellSyntax([string]$Path) {
    $tokens = $null
    $parseErrors = $null
    [void][Management.Automation.Language.Parser]::ParseFile($Path, [ref]$tokens, [ref]$parseErrors)
    if (@($parseErrors).Count -gt 0) {
        $details = @($parseErrors | Select-Object -First 3 | ForEach-Object { $_.Message }) -join '; '
        throw ('PowerShell syntax errors in ' + $Path + ': ' + $details)
    }
}

function Copy-TreeWithoutJunctions([string]$Source, [string]$Destination) {
    New-Item -ItemType Directory -Path $Destination -Force | Out-Null
    # Never copy deploy.key into the repository: it belongs outside Git.
    & robocopy.exe $Source $Destination /E /XJ /R:2 /W:1 /COPY:DAT /DCOPY:DAT /NP /NJH /NJS /NFL /NDL /XF deploy.key | Out-Null
    $result = $LASTEXITCODE
    $global:LASTEXITCODE = 0
    if ($result -ge 8) { throw ('File staging failed; robocopy exit code ' + $result) }
}

function Protect-KeyFile([string]$Path) {
    # Readable only by current account, local Administrators, and SYSTEM.
    $acl = Get-Acl -LiteralPath $Path
    $acl.SetAccessRuleProtection($true, $false)
    $currentSid = [Security.Principal.WindowsIdentity]::GetCurrent().User
    $sids = @($currentSid,
              (New-Object Security.Principal.SecurityIdentifier('S-1-5-18')),
              (New-Object Security.Principal.SecurityIdentifier('S-1-5-32-544')))
    foreach ($sid in $sids) {
        $rule = [System.Security.AccessControl.FileSystemAccessRule]::new(
            $sid, [System.Security.AccessControl.FileSystemRights]::FullControl,
            [System.Security.AccessControl.AccessControlType]::Allow)
        $acl.SetAccessRule($rule)
    }
    Set-Acl -LiteralPath $Path -AclObject $acl
}

function Confirm-Installation([string]$RoleLabel) {
    try {
        Add-Type -AssemblyName System.Windows.Forms
        $answer = [System.Windows.Forms.MessageBox]::Show(
            "Dry run completed. Start the LIVE $RoleLabel installation and restoration on this Windows machine?`n`nChoose No to exit without installing anything.",
            'TBMC deployment - approval required',
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Warning,
            [System.Windows.Forms.MessageBoxDefaultButton]::Button2)
        return ($answer -eq [System.Windows.Forms.DialogResult]::Yes)
    }
    catch {
        $answer = Read-Host 'To start LIVE installation, type INSTALL (otherwise press Enter)'
        return ($answer -eq 'INSTALL')
    }
}

# TBMC software acquisition. Windows PowerShell 5.1 compatible.
# Safe preflight only: retrieves packages, validates them, and updates client.json.
# Does not execute installation packages or restore databases.
function Set-TbmcJsonField([object]$Object, [string]$Name, [object]$Value) {
    if ($null -eq $Object.PSObject.Properties[$Name]) {
        $Object | Add-Member -MemberType NoteProperty -Name $Name -Value $Value
    } else { $Object.PSObject.Properties[$Name].Value = $Value }
}
function Get-TbmcJsonField([object]$Object, [string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Name)) { return '' }
    if ($null -eq $Object.PSObject.Properties[$Name]) { return '' }
    return [string]$Object.PSObject.Properties[$Name].Value
}
function Get-TbmcMsiProperty([string]$FilePath,[string]$Property) {
    $wi=$null;$db=$null;$view=$null;$record=$null
    try {
        $wi=New-Object -ComObject WindowsInstaller.Installer
        $db=$wi.OpenDatabase($FilePath,0)
        $view=$db.OpenView("SELECT ``Value`` FROM ``Property`` WHERE ``Property``='$Property'")
        $view.Execute()
        $record=$view.Fetch()
        if($null -eq $record){return ''}
        return [string]$record.StringData(1)
    } finally {
        if($record){[void][Runtime.InteropServices.Marshal]::ReleaseComObject($record)}
        if($view){try{$view.Close()}catch{};[void][Runtime.InteropServices.Marshal]::ReleaseComObject($view)}
        if($db){[void][Runtime.InteropServices.Marshal]::ReleaseComObject($db)}
        if($wi){[void][Runtime.InteropServices.Marshal]::ReleaseComObject($wi)}
    }
}
function Get-TbmcGithubAssetDigest([string]$Repository,[string]$Tag,[string]$FileName) {
    try {
        $api="https://api.github.com/repos/$Repository/releases/tags/$Tag"
        $release=Invoke-RestMethod -Uri $api -Headers @{'User-Agent'='TBMC-Deployment-Acquisition';'Accept'='application/vnd.github+json'} -TimeoutSec 30
        $assets=@($release.assets | Where-Object { $_.name -ceq $FileName })
        if($assets.Count -eq 1 -and [string]$assets[0].digest -match '^sha256:([a-fA-F0-9]{64})$') {
            return $Matches[1].ToUpperInvariant()
        }
    } catch { Write-Warning "Could not obtain publisher release digest for $FileName : $($_.Exception.Message)" }
    return ''
}
function Assert-TbmcArchive([string]$Path,[string]$Format,[string]$ExpectedMember) {
    $file=Get-Item -LiteralPath $Path
    if($file.Length -lt 100KB){throw "File is too small to be a complete $Format package: $Path"}
    if($Format -eq 'zip') {
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $archive=[IO.Compression.ZipFile]::OpenRead($Path)
        try {
            if($archive.Entries.Count -eq 0){throw "Empty ZIP: $Path"}
            if($ExpectedMember) {
                $matches=@($archive.Entries | Where-Object { $_.Name -ieq $ExpectedMember })
                if($matches.Count -eq 0){throw "ZIP does not contain expected $ExpectedMember : $Path"}
            }
        } finally {$archive.Dispose()}
    } elseif($Format -eq 'gzip') {
        $stream=[IO.File]::OpenRead($Path)
        try { if(($stream.ReadByte() -ne 31) -or ($stream.ReadByte() -ne 139)){throw "Invalid GZip header in $Path"} }
        finally {$stream.Dispose()}
    } elseif($Format -eq 'exe') {
        $stream=[IO.File]::OpenRead($Path)
        try { if(($stream.ReadByte() -ne 77) -or ($stream.ReadByte() -ne 90)){throw "Not a Windows PE executable: $Path"} }
        finally {$stream.Dispose()}
    }
}
function Receive-TbmcOfficialFile([string]$Name,[string[]]$Urls,[string]$Destination) {
    $allowed=@('releases.inductiveautomation.com','archive.mariadb.org','mirror.dogado.de','github.com',
               'dl.influxdata.com','download.influxdata.com')
    $errors=New-Object 'System.Collections.Generic.List[string]'
    foreach($url in $Urls) {
        if([string]::IsNullOrWhiteSpace($url)){continue}
        $u=$null
        try {$u=[uri]$url} catch { $errors.Add("Bad URL: $url"); continue }
        if($u.Scheme -ne 'https' -or ($u.Host -notin $allowed)) {
            $errors.Add("Unapproved source host: $url"); continue
        }
        $part="$Destination.$([guid]::NewGuid().ToString('N')).partial"
        try {
            Write-Host "Downloading $Name from $($u.Host) ..." -ForegroundColor Cyan
            if(Get-Command curl.exe -ErrorAction SilentlyContinue) {
                & curl.exe --fail --location --retry 3 --connect-timeout 30 --output $part $url
                if($LASTEXITCODE -ne 0){throw "curl.exe exited with code $LASTEXITCODE"}
            } else {
                Invoke-WebRequest -Uri $url -UseBasicParsing -OutFile $part -TimeoutSec 3600
            }
            if(-not(Test-Path -LiteralPath $part -PathType Leaf)){throw 'No downloaded file appeared'}
            if((Get-Item -LiteralPath $part).Length -lt 100KB){throw 'Downloaded file is unexpectedly small'}
            Move-Item -LiteralPath $part -Destination $Destination -ErrorAction Stop
            return $url
        } catch {
            $errors.Add("$($u.Host): $($_.Exception.Message)")
            if(Test-Path -LiteralPath $part){Remove-Item -LiteralPath $part -Force -ErrorAction SilentlyContinue}
        }
    }
    throw "Could not download $Name from approved sources: $($errors -join ' | ')"
}
function Resolve-TbmcSoftware([string]$ServerRole,[string]$ClientConfig,[string]$InstallerFolder,[string]$RootFolder) {
    Write-Host "`nTBMC SOFTWARE ACQUISITION: $ServerRole" -ForegroundColor Cyan
    Write-Host 'Checking all role-specific software in one pass (no applications will be installed).'
    $cfg=Get-Content -LiteralPath $ClientConfig -Raw | ConvertFrom-Json
    $issues=New-Object 'System.Collections.Generic.List[string]'
    $results=New-Object 'System.Collections.Generic.List[object]'
    New-Item -Path $InstallerFolder -ItemType Directory -Force | Out-Null
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

    # Each record pins the application release, not merely a plausible filename.
    $packages=@()
    if($ServerRole -eq 'Ignition') {
        $packages+=@{
            Label='Ignition Gateway 8.3.4'; Prefix='ignition'; VersionField='ignitionVersion'; Version='8.3.4'
            Name='ignition-8.3.4-windows-x64-installer.exe'; Pattern='(?i)^ignition-8\.3\.4-windows-x64-installer\.exe$'
            Urls=@('https://releases.inductiveautomation.com/release/8.3.4/2026030309/ignition-8.3.4-windows-x64-installer.exe')
            Type='exe'; SignedBy='Inductive Automation'; PinnedSha=''; Repo=''; Tag=''; ExpectedMember=''
        }
        $packages+=@{
            Label='MariaDB 10.11'; Prefix='mariaDb'; VersionField=''; Version='10.11'
            Name='mariadb-10.11.19-winx64.msi'; Pattern='(?i)^mariadb-10\.11\.\d+-winx64\.msi$'
            Urls=@('https://archive.mariadb.org/mariadb-10.11.19/winx64-packages/mariadb-10.11.19-winx64.msi',
                   'https://mirror.dogado.de/mariadb/mariadb-10.11.19/winx64-packages/mariadb-10.11.19-winx64.msi')
            Type='msi'; SignedBy='MariaDB'; PinnedSha='83AF9D523BF7BA989EA0031D4EBCA7E4DC21E49F435122570DDC87F0620B3A5C'
            Repo=''; Tag=''; ExpectedMember=''
        }
    } else {
        $packages+=@{
            Label='QuestDB 9.3.3 Windows runtime'; Prefix='questDb'; VersionField='questDbVersion'; Version='9.3.3'
            Name='questdb-9.3.3-rt-windows-x86-64.tar.gz'; Pattern='(?i)^questdb-9\.3\.3-rt-windows-x86-64\.tar\.gz$'
            Urls=@('https://github.com/questdb/questdb/releases/download/9.3.3/questdb-9.3.3-rt-windows-x86-64.tar.gz')
            Type='gzip'; SignedBy=''; PinnedSha=''; Repo='questdb/questdb'; Tag='9.3.3'; ExpectedMember=''
        }
        $packages+=@{
            Label='InfluxDB 2.8.0 Windows server'; Prefix='influxDb'; VersionField='influxDbVersion'; Version='2.8.0'
            Name='influxdb2-2.8.0-windows_amd64.zip'; Pattern='(?i)^influxdb2-2\.8\.0-windows[_-]amd64\.zip$'
            Urls=@('https://dl.influxdata.com/influxdb/releases/influxdb2-2.8.0-windows_amd64.zip',
                   'https://download.influxdata.com/influxdb/releases/influxdb2-2.8.0-windows_amd64.zip',
                   'https://dl.influxdata.com/influxdb/releases/influxdb2-2.8.0-windows-amd64.zip')
            Type='zip'; SignedBy=''; PinnedSha=''; Repo=''; Tag=''; ExpectedMember='influxd.exe'
        }
        $packages+=@{
            Label='InfluxDB 2.8.0 CLI (for metadata restoration)'; Prefix='influxCli'; VersionField=''; Version='2.8.0'
            Name='influxdb2-client-2.8.0-windows-amd64.zip'; Pattern='(?i)^influxdb2-client-2\.8\.0-windows-amd64\.zip$'
            Urls=@('https://dl.influxdata.com/influxdb/releases/influxdb2-client-2.8.0-windows-amd64.zip')
            Type='zip'; SignedBy=''; PinnedSha='28AAB065FA81C965BFE16D0F0ED8DD509EEDBE88F5FE6BC4A3D19B91EE01F87E'
            Repo=''; Tag=''; ExpectedMember='influx.exe'
        }
    }

    foreach($p in $packages) {
        try {
            $currentVersion=Get-TbmcJsonField $cfg $p.VersionField
            if($p.VersionField -and $currentVersion -and $currentVersion -ne $p.Version) {
                throw "$($p.Label): existing $($p.VersionField) is '$currentVersion', which disagrees with the source version '$($p.Version)'."
            }
            $nameField="$($p.Prefix)InstallerName"
            $urlField="$($p.Prefix)InstallerUrl"
            $shaField="$($p.Prefix)InstallerSha256"
            $currentName=Get-TbmcJsonField $cfg $nameField
            $candidates=@(Get-ChildItem -LiteralPath $InstallerFolder -File | Where-Object { $_.Name -match $p.Pattern })
            if($candidates.Count -gt 1) {
                $sameAsCurrent=@($candidates|Where-Object{$_.Name -ieq $currentName})
                if($sameAsCurrent.Count -eq 1){$candidates=$sameAsCurrent}
                else{throw "Multiple installers match $($p.Label): $($candidates.Name -join ', '). Leave one intended version in $InstallerFolder."}
            }
            $source='existing local installer'
            if($candidates.Count -eq 0) {
                $path=Join-Path $InstallerFolder $p.Name
                $source=Receive-TbmcOfficialFile $p.Label $p.Urls $path
                $candidates=@(Get-Item -LiteralPath $path)
            }
            $item=$candidates[0]
            $hash=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToUpperInvariant()
            $expected=Get-TbmcJsonField $cfg $shaField
            if($expected -and $expected -notmatch '^[a-fA-F0-9]{64}$') {
                throw "$shaField has an invalid checksum value."
            }
            $check='Official HTTPS download + local SHA-256 pin (not publisher-hash verified)'
            if($expected -and $expected.ToUpperInvariant() -ne $hash) {
                throw "$($item.Name) does not match the SHA-256 already pinned in client.json."
            }
            if($expected){$check='Matched previously pinned SHA-256'}
            if($p.PinnedSha -and $item.Name -ieq $p.Name) {
                if($hash -ne $p.PinnedSha){throw "SHA-256 does not match published checksum for $($item.Name)"}
                $check='Matches independently published release SHA-256'
            }
            if($p.Repo) {
                $digest=Get-TbmcGithubAssetDigest $p.Repo $p.Tag $item.Name
                if($digest) {
                    if($hash -ne $digest){throw "GitHub official release digest mismatch: $($item.Name)"}
                    $check='Matches GitHub release asset SHA-256 digest'
                }
            }
            if($p.Type -eq 'msi') {
                $product=Get-TbmcMsiProperty $item.FullName 'ProductName'
                $ver=Get-TbmcMsiProperty $item.FullName 'ProductVersion'
                if($product -notmatch '(?i)MariaDB' -or $ver -notmatch '^10\.11(\.|$)') {
                    throw "Wrong MariaDB MSI product/version: '$product' / '$ver'"
                }
            }
            if($p.Type -eq 'exe') {
                Assert-TbmcArchive $item.FullName 'exe' ''
            } elseif($p.Type -eq 'zip') {
                Assert-TbmcArchive $item.FullName 'zip' $p.ExpectedMember
            } elseif($p.Type -eq 'gzip') {
                Assert-TbmcArchive $item.FullName 'gzip' ''
            }
            if($p.SignedBy) {
                $sig=Get-AuthenticodeSignature -LiteralPath $item.FullName
                if($sig.Status -eq 'Valid' -and $null -ne $sig.SignerCertificate -and
                   [string]$sig.SignerCertificate.Subject -match $p.SignedBy) {
                    $check+='; valid Authenticode publisher signature'
                } elseif($p.Type -eq 'exe' -or ($p.Type -eq 'msi' -and $check -notmatch 'published|pinned')) {
                    throw "Cannot establish trusted Authenticode signature for $($item.Name): $($sig.Status)."
                }
            }
            Set-TbmcJsonField $cfg $nameField $item.Name
            Set-TbmcJsonField $cfg $shaField $hash
            Set-TbmcJsonField $cfg $urlField $p.Urls[0]
            if($p.VersionField){Set-TbmcJsonField $cfg $p.VersionField $p.Version}
            if($p.Prefix -eq 'ignition') {
                Set-TbmcJsonField $cfg 'ignitionInstallerArguments' '/quiet'
            }
            Write-Host "READY  $($p.Label): $($item.Name)" -ForegroundColor Green
            $results.Add([pscustomobject]@{Product=$p.Label;Filename=$item.Name;Bytes=$item.Length;Sha256=$hash;Verification=$check;Source=$source})
        } catch {
            $message="$($p.Label): $($_.Exception.Message)"
            $issues.Add($message)
            Write-Host "BLOCKED  $message" -ForegroundColor Red
        }
    }

    # The age tool is a supporting executable, not an application installed as a service.
    try {
        $ageCommand=Get-Command age.exe -ErrorAction SilentlyContinue
        if(-not $ageCommand) {
            $toolRoot=Join-Path $RootFolder 'Tools\age'
            $ageExe=Join-Path $toolRoot 'age.exe'
            if(-not(Test-Path -LiteralPath $ageExe -PathType Leaf)) {
                $ageZip=Join-Path $InstallerFolder 'age-v1.3.2-windows-amd64.zip'
                $ageHash=Get-TbmcGithubAssetDigest 'FiloSottile/age' 'v1.3.2' 'age-v1.3.2-windows-amd64.zip'
                if(-not(Test-Path -LiteralPath $ageZip -PathType Leaf)) {
                    [void](Receive-TbmcOfficialFile 'age v1.3.2 Windows' @('https://github.com/FiloSottile/age/releases/download/v1.3.2/age-v1.3.2-windows-amd64.zip') $ageZip)
                }
                $localHash=(Get-FileHash -LiteralPath $ageZip -Algorithm SHA256).Hash.ToUpperInvariant()
                if($ageHash -and $ageHash -ne $localHash){throw 'age release asset digest mismatch'}
                Assert-TbmcArchive $ageZip 'zip' 'age.exe'
                $temp=Join-Path $RootFolder ('_age-unpack-'+[guid]::NewGuid().ToString('N'))
                try {
                    Expand-Archive -LiteralPath $ageZip -DestinationPath $temp -Force
                    $found=@(Get-ChildItem -LiteralPath $temp -Recurse -File -Filter 'age.exe')
                    if($found.Count -ne 1){throw 'age ZIP does not contain one unambiguous age.exe'}
                    New-Item -Path $toolRoot -ItemType Directory -Force | Out-Null
                    Copy-Item -LiteralPath $found[0].FullName -Destination $ageExe -Force
                } finally { if(Test-Path $temp){Remove-Item -LiteralPath $temp -Recurse -Force} }
            }
            $env:PATH=$toolRoot+';'+$env:PATH
        }
        $output=(& age.exe --version 2>&1 | Out-String).Trim()
        if($LASTEXITCODE -ne 0){throw "age.exe returned error: $output"}
        Write-Host "READY  age decryption CLI: $output" -ForegroundColor Green
    } catch {
        $message="age CLI: $($_.Exception.Message)"
        $issues.Add($message)
        Write-Host "BLOCKED  $message" -ForegroundColor Red
    }

    Set-TbmcJsonField $cfg 'softwareDirectory' $InstallerFolder
    Set-TbmcJsonField $cfg 'artifactDirectory' (Join-Path $RootFolder 'TBMC-Deploy\artifacts')
    Set-TbmcJsonField $cfg 'ageIdentityKey' (Join-Path $RootFolder 'Secure\deploy.key')

    # Also inventory any additional installer fields not included in the 4 known products.
    $known=@('ignitionInstallerName','mariaDbInstallerName','questDbInstallerName','influxDbInstallerName','influxCliInstallerName')
    foreach($prop in @($cfg.PSObject.Properties | Where-Object { $_.Name -like '*InstallerName' -and $_.Name -notin $known })) {
        $value=[string]$prop.Value
        if($value -and -not(Test-Path -LiteralPath (Join-Path $InstallerFolder $value) -PathType Leaf)) {
            $issues.Add("Additional configured installer '$($prop.Name)': $value is missing; no approved source/verification rule was provided.")
        }
    }

    $reportFile=Join-Path (Join-Path $RootFolder 'Logs') 'TBMC-Software-Readiness.json'
    $report=[pscustomobject]@{
        Role=$ServerRole; TimeUtc=[DateTime]::UtcNow.ToString('o'); InstallersFolder=$InstallerFolder
        VerifiedPackages=@($results.ToArray()); OutstandingIssues=@($issues.ToArray());
        Note='A locally computed SHA-256 pins file integrity; it is not independent publisher verification unless stated in Verification.'
    }
    $report | ConvertTo-Json -Depth 8 | Out-File -LiteralPath $reportFile -Encoding UTF8
    $savePath="$ClientConfig.before-auto-acquire-$(Get-Date -Format 'yyyyMMdd-HHmmss').bak"
    Copy-Item -LiteralPath $ClientConfig -Destination $savePath
    $text=$cfg | ConvertTo-Json -Depth 80
    [IO.File]::WriteAllText($ClientConfig,$text+[Environment]::NewLine,(New-Object System.Text.UTF8Encoding($false)))
    Write-Host "Software readiness report: $reportFile" -ForegroundColor Cyan
    if($issues.Count -gt 0) {
        Write-Host "`nOutstanding acquisition issues ($($issues.Count)):" -ForegroundColor Yellow
        foreach($problem in $issues){Write-Host (' - '+$problem) -ForegroundColor Yellow}
        throw "Acquisition did not clear all $ServerRole prerequisites. No application has been installed."
    }
    Write-Host "All $ServerRole software acquisition checks completed. Proceeding to repository dry run." -ForegroundColor Green
}

try {
    Write-Host "`nTBMC Deployment: $Role Server" -ForegroundColor Cyan
    Write-Host 'Step 1/5 - Locate extracted repository on the Windows desktop'
    $root = [IO.Path]::GetFullPath($DestinationRoot)
    $repo = Join-Path $root 'TBMC-Deploy'
    $source = Find-ExtractedRepository
    if (-not $source -and -not (Test-TbmcRepository $repo)) {
        throw 'Cannot find TBMC-Deploy-main on this Windows desktop. Unzip the GitHub repository to the Desktop and run the script from inside that folder.'
    }
    if ($source) { Write-Host ('Found source: ' + $source) }

    Write-Host 'Step 2/5 - Prepare C:\TBMC folders and stage deployment files'
    foreach ($folder in @($root, (Join-Path $root 'Installers'), (Join-Path $root 'Backups'),
                         (Join-Path $root 'Logs'), (Join-Path $root 'Secure'))) {
        New-Item -ItemType Directory -Path $folder -Force | Out-Null
    }
    if (Test-TbmcRepository $repo) {
        Write-Host ('Using previously staged repository: ' + $repo) -ForegroundColor Yellow
        Write-Host 'Existing client configuration and deployment journals have been preserved.'
    }
    else {
        if (Test-Path -LiteralPath $repo) {
            throw ('An incomplete folder already exists at ' + $repo + '. Refusing to overwrite it.')
        }
        if (-not $source) { throw 'No extracted repository folder was found.' }
        Copy-TreeWithoutJunctions $source $repo
        Write-Host ('Repository staged at: ' + $repo) -ForegroundColor Green
    }

    $entryPath = Join-Path $repo $RelativeEntry
    Assert-PowerShellSyntax $entryPath
    $configDir = Join-Path $repo 'config'
    $configOut = Join-Path $configDir 'client.json'
    $configCreatedFromTemplate = $false
    if (-not (Test-Path -LiteralPath $configOut -PathType Leaf)) {
        $copied = $false
        foreach ($folder in @($PSScriptRoot) + @(Get-DesktopFolders)) {
            $externalConfig = Join-Path $folder 'client.json'
            if (Test-Path -LiteralPath $externalConfig -PathType Leaf) {
                Copy-Item -LiteralPath $externalConfig -Destination $configOut
                $copied = $true
                Write-Host ('Client configuration copied from: ' + $externalConfig)
                break
            }
        }
        if (-not $copied) {
            $template = Join-Path $configDir 'deployment.example.json'
            if (-not (Test-Path -LiteralPath $template -PathType Leaf)) {
                throw 'Missing config\deployment.example.json and no client.json was supplied.'
            }
            Copy-Item -LiteralPath $template -Destination $configOut
            $configCreatedFromTemplate = $true
            Write-Warning 'Created client.json from the EXAMPLE template. It must be reviewed before live installation.'
        }
    }
    try { $null = Get-Content -LiteralPath $configOut -Raw | ConvertFrom-Json }
    catch { throw ('Invalid config\client.json: ' + $_.Exception.Message) }
    $templatePath = Join-Path $configDir 'deployment.example.json'
    $configIsTemplate = $false
    if (Test-Path -LiteralPath $templatePath -PathType Leaf) {
        $configIsTemplate = ((Get-FileHash -LiteralPath $configOut -Algorithm SHA256).Hash -eq
                             (Get-FileHash -LiteralPath $templatePath -Algorithm SHA256).Hash)
    }

    # Automatically stage a separately supplied installer folder when present.
    $installerDest = Join-Path $root 'Installers'
    foreach ($folder in @($PSScriptRoot) + @(Get-DesktopFolders)) {
        foreach ($name in @('TBMC-Installers','Installers')) {
            $possible = Join-Path $folder $name
            if ((Test-Path -LiteralPath $possible -PathType Container) -and
                -not ($possible.TrimEnd('\') -ieq $installerDest.TrimEnd('\'))) {
                Copy-TreeWithoutJunctions $possible $installerDest
                Write-Host ('Offline installers staged from: ' + $possible)
            }
        }
    }

    Write-Host 'Step 3/5 - Find the age decryption identity, if supplied'
    $key = Join-Path $root 'Secure\deploy.key'
    if (-not (Test-Path -LiteralPath $key -PathType Leaf)) {
        $keyCandidates = New-Object 'System.Collections.Generic.List[string]'
        foreach ($folder in @($PSScriptRoot) + @(Get-DesktopFolders)) {
            $keyCandidates.Add((Join-Path $folder 'deploy.key'))
        }
        foreach ($possible in @($keyCandidates | Select-Object -Unique)) {
            if (Test-Path -LiteralPath $possible -PathType Leaf) {
                Copy-Item -LiteralPath $possible -Destination $key
                Write-Host ('Private key staged securely from: ' + $possible)
                Write-Warning 'After deployment, securely remove any unprotected Desktop copy of deploy.key.'
                break
            }
        }
    }
    if (Test-Path -LiteralPath $key -PathType Leaf) { Protect-KeyFile $key }

    Write-Host 'Step 4/6 - Check and automatically acquire all required software'
    Resolve-TbmcSoftware -ServerRole $Role -ClientConfig $configOut -InstallerFolder $installerDest -RootFolder $root

    Write-Host 'Step 4/5 - Run the repository orchestrator preflight'
    Write-Host ('Entry: ' + $entryPath)
    Write-Host ('Config: ' + $configOut)
    Write-Host ('Offline installer directory: ' + $installerDest)
    if (-not (Test-Path -LiteralPath $key -PathType Leaf)) {
        throw ('Missing private age key. Place deploy.key on the Desktop, then run THIS SAME script again. It will stage the file at ' + $key)
    }

    Push-Location $repo
    try {
        $arguments = @{
            ConfigPath = $configOut
            InstallerPath = $installerDest
            AgeIdentityPath = $key
        }
        $global:LASTEXITCODE = 0
        & $entryPath @arguments -DryRun
        if (-not $? -or $LASTEXITCODE -ne 0) {
            throw 'The underlying installer dry run failed. Check the message above for missing files, versions, hashes, or settings.'
        }
        Write-Host 'Dry run succeeded.' -ForegroundColor Green

        if ($DryRunOnly) {
            Write-Host 'DryRunOnly was selected. No application installation was started.' -ForegroundColor Green
            exit 0
        }
        if ($configCreatedFromTemplate -or $configIsTemplate) {
            throw ('The configuration is still identical to the example template: ' + $configOut + '. Supply verified client settings, installer versions and hashes; then rerun the SAME launcher.')
        }
        Write-Host 'Step 5/5 - Request approval for live installation'
        if (-not (Confirm-Installation $Role)) {
            Write-Host 'Live installation cancelled. Preparation is complete; rerun this launcher later.' -ForegroundColor Yellow
            exit 0
        }
        $global:LASTEXITCODE = 0
        if ($Resume) { & $entryPath @arguments -Resume }
        else { & $entryPath @arguments }
        if (-not $? -or $LASTEXITCODE -ne 0) {
            throw 'Installer did not return a clean success status. Review its logs before proceeding.'
        }
        Write-Host "`n$Role installation orchestrator finished. Review application validation before enabling live integrations." -ForegroundColor Green
        exit 0
    }
    finally { Pop-Location }
}
catch {
    Write-Host "`nTBMC preparation or deployment stopped safely:" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host 'You can rerun this same script after resolving the issue; existing files are preserved.' -ForegroundColor Yellow
    exit 1
}
