# Configuration difference verification

{
  "UTC": "2026-11-25T19:05:13.850379+00:00",
  "Comparison": "Fresh native full default provider exports and native TBMC project exports",
  "Normalization": "tags matched by exact full path; omitted enabled normalized to documented defaultTrue; other property values compared directly",
  "HierarchyUnchanged": true,
  "BeforeTagNodes": 1839,
  "AfterTagNodes": 1839,
  "ExpectedApprovedPropertyCount": 40,
  "OnlyApprovedSourceAndExplicitEnablePropertiesChanged": true,
  "TBMCProjectFiles": 494,
  "TBMCProjectResourcesUnchanged": true,
  "ParentUDTDefinitionsUnchanged": true,
  "OtherEquipmentAndStatusAlarmsHistoryPermissionsUnchanged": true,
  "NewCommissionInstrumentationProjects": [
    "TBMC_COM06A_DIAG_0224 (temporary diagnostic project removed at closeout)",
    "TBMC_COM06A_PilotGuard_0224 (PhaseL quality/source rollback guard retained while pilot live)"
  ],
  "NoExistingProjectResourceEdit": true
}

| Tag | Property | Before | After | Approved |
|---|---|---|---|---|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/AFOAMT|enabled|False|True|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/AFOAMT|opcItemPath|ns=1;s=[Sample_Device]_Meta:Realistic/Realistic5|nsu=http://www.sartorius.com/BioPAT_MFCS_OPC_Server/Units;s=U01.AFOAMT.Value|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/AFOAMT|opcServer|Ignition OPC UA Server|MFCS_OPCUA|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/AIROV|enabled|False|True|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/AIROV|opcItemPath|ns=1;s=[Sample_Device]_Meta:Realistic/Realistic0|nsu=http://www.sartorius.com/BioPAT_MFCS_OPC_Server/Units;s=U01.AIROV.Value|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/AIROV|opcServer|Ignition OPC UA Server|MFCS_OPCUA|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/BASET|enabled|False|True|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/BASET|opcItemPath|ns=1;s=[Sample_Device]_Meta:Realistic/Realistic0|nsu=http://www.sartorius.com/BioPAT_MFCS_OPC_Server/Units;s=U01.BASET.Value|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/BASET|opcServer|Ignition OPC UA Server|MFCS_OPCUA|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/JTEMP|enabled|False|True|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/JTEMP|opcItemPath|ns=1;s=[Sample_Device]_Meta:Realistic/Realistic9|nsu=http://www.sartorius.com/BioPAT_MFCS_OPC_Server/Units;s=U01.JTEMP.Value|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/JTEMP|opcServer|Ignition OPC UA Server|MFCS_OPCUA|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/KeyCPP1|enabled|False|True|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/KeyCPP2|enabled|False|True|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/KeyCPP3|enabled|False|True|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/STIRR|enabled|False|True|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/STIRR|opcItemPath|ns=1;s=[Sample_Device]_Meta:Realistic/Realistic1|nsu=http://www.sartorius.com/BioPAT_MFCS_OPC_Server/Units;s=U01.STIRR.Value|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/STIRR|opcServer|Ignition OPC UA Server|MFCS_OPCUA|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/STIRR|valueSource|memory|opc|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/SUBS_A|enabled|False|True|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/SUBS_A|opcItemPath|ns=1;s=[Sample_Device]_Meta:Realistic/Realistic1|nsu=http://www.sartorius.com/BioPAT_MFCS_OPC_Server/Units;s=U01.SUBS_A.Value|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/SUBS_A|opcServer|Ignition OPC UA Server|MFCS_OPCUA|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/SUBS_B|enabled|False|True|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/SUBS_B|opcItemPath|ns=1;s=[Sample_Device]_Meta:Realistic/Realistic2|nsu=http://www.sartorius.com/BioPAT_MFCS_OPC_Server/Units;s=U01.SUBS_B.Value|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/SUBS_B|opcServer|Ignition OPC UA Server|MFCS_OPCUA|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/SUBS_C|enabled|False|True|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/SUBS_C|opcItemPath|ns=1;s=[Sample_Device]_Meta:Realistic/Realistic7|nsu=http://www.sartorius.com/BioPAT_MFCS_OPC_Server/Units;s=U01.SUBS_C.Value|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/SUBS_C|opcServer|Ignition OPC UA Server|MFCS_OPCUA|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/TEMP|enabled|False|True|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/TEMP|opcItemPath|ns=1;s=[Sample_Device]_Meta:Realistic/Realistic2|nsu=http://www.sartorius.com/BioPAT_MFCS_OPC_Server/Units;s=U01.TEMP.Value|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/TEMP|opcServer|Ignition OPC UA Server|MFCS_OPCUA|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/VWEIGHT|enabled|False|True|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/VWEIGHT|opcItemPath|ns=1;s=[Sample_Device]_Meta:Realistic/Realistic4|nsu=http://www.sartorius.com/BioPAT_MFCS_OPC_Server/Units;s=U01.VWEIGHT.Value|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/VWEIGHT|opcServer|Ignition OPC UA Server|MFCS_OPCUA|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/pH|enabled|False|True|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/pH|opcItemPath|ns=1;s=[Sample_Device]_Meta:Realistic/Realistic0|nsu=http://www.sartorius.com/BioPAT_MFCS_OPC_Server/Units;s=U01.pH.Value|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/pH|opcServer|Ignition OPC UA Server|MFCS_OPCUA|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/pO2|enabled|False|True|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/pO2|opcItemPath|ns=1;s=[Sample_Device]_Meta:Realistic/Realistic7|nsu=http://www.sartorius.com/BioPAT_MFCS_OPC_Server/Units;s=U01.pO2.Value|True|
|[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01/pO2|opcServer|Ignition OPC UA Server|MFCS_OPCUA|True|