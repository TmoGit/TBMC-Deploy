# Controlled live integration report — TBMC-COM-06A

26 November2026 • Prepared 2026-11-25T19:01:46.593830+00:00 • **Controlled pilot; formal SAT not completed**

## Result and disposition

**12 of16 process measurements on exactly one existing equipment instance are now live and verified.** Pilot: `[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01`, physical MFCS **U01 / Biostat B TWIN_L_814**, explicitly confirmed by the user. The user approved execution in the current session, the necessary initial disabled-tag enablement and leaving a successful pilot live for review. Initial TEMP/pH/pO2 test succeeded; original Commission06A PhaseI authorized the eligible same-instance expansion. No second MFCS or UNICORN instance changed.

Live: **TEMP, pH, pO2, AFOAMT, BASET, SUBS_A, SUBS_B, SUBS_C, VWEIGHT, JTEMP, AIROV, STIRR**. Held unchanged: **CO2SP, AIRSP, N2SP, O2SP**. CO2SP has unresolved ccm/lpm and Value-versus-Setpoint semantics; other SP-suffixed fields also require intended-value confirmation. No conversion or substitution was invented. Static zero readings are not failures and no process operation was initiated to change values.

The pilot is left live for Acropolis review with the scoped **quality/source rollback guard**. Current status is `C:\TBMC\Logs\TBMC-COM06A-Pilot-Guard.json`; consult it because this package is a frozen snapshot. The Gateway remains in development trial, not reset here, with captured expiry around03:27Asia/Taipei on26November. The guard is designed to restore the original disabled simulation configuration if quality is lost, including at trial expiry. Human review and permanent-licensing/formal-SAT disposition remain pending.

## Actual execution and verification

- Before: disabled sample-OPC measurements and references; STIRR disabled memory literal1. Exported definitions, full selected instance, effective properties, local/inherited provenance, UI resources, values/quality/time, status, alarm state, history and protected native backups. No parent definition or instance was replaced.
- Preflight: selected MFCS node AccessLevel/UserAccessLevel=1(CurrentRead only), valid Good values, matching units, compatible Double→existingFloat4 data, no active simulation writer on selected path/type, disabled alarms/history preserved. No OPC writes, server method calls, instrument control, notifications, alarm acknowledgement or thresholds forced.
- Initial live test: three process members and their existing KeyCPP references enabled. Addresses changed at member level with MergeOverwrite. Immediate native export exactly matched the approved property set. Approximately117.5sec of source/UDT/status observation and existing overview/detail captures retained. A first harness attempt rejected an unexpected native export wrapper before any mutation; corrected direct-object handling and retry are preserved, not concealed or called an equipment failure.
- PhaseI: nine further eligible read-only U01 measurements switched on the same instance. STIRR changed memory→opc; eight other members already opc and only needed source rerouting/enablement. Immediate diff passed and four samples across60sec remained Good. No SP field was included.
- Final source comparison: all12 direct Double values cast to Float4 equal the existing UDT values **exactly** at the final snapshot. Each captured existing detail numeric field equals that UDT value at its original up-to2-decimal display precision. The existing overview displays pH/pO2/TEMP; whole-unit TEMP/AFOAMT/BASET detail gauges retain their original rounding and ranges. Before/after images and navigation are intact. No bindings, colors, media, formats or navigation were edited.

## Configuration preservation

The full native default-provider comparison has **1839 nodes before and after** (including root), identical paths/types, unchanged parent UDT definitions and **exactly40 approved source/enable property changes**:24 server/item addresses,15 enabled flags and STIRR's valueSource. No other member, equipment, alarm, threshold, history, security or status configuration differs. All **494 TBMC project resources are byte-identical**. A separate owned diagnostic project was used for supported reads/configuration; it is removed at closeout. The owned rollback-guard project remains active solely for PhaseL protection and is explicitly accounted for, not an edit to the FAT application. [Machine diff](07_Configuration_Diff.json), [human diff](07_Configuration_Diff.md).

## Alarm, status and historian limits

No active pilot alarms were returned in baseline/final queries. Existing applicable alarm definitions were disabled and stayed disabled; this proves preservation, **not alarm-firing/notification performance**. The alarm editor's unselected default controls were not saved or treated as actual tag settings. Source-quality badge changed naturally to “Source quality good”; physical active/in-use/acquired status members remain disabled memory fields, so actual equipment operating-state validation is not claimed. Existing background/image settings remain unchanged.

All15 affected process/reference members retain effective historyEnabled=false, even where a provider string or parent default mentionsInfluxDB. No historian setting was enabled or rewritten; historian sample flow is **NOT TESTED—disabled in the existing instance**, not passed based on provider status. Alarm operational tests, actual operating-state semantics, historian commissioning and formal SAT remain separate work.

## Regression and outstanding items

Selected image/details/overview render, fields track their original member paths, all12 final numeric comparisons pass, adjacent BRX5-02-02 and AVANT cards remain unavailable/disabled as before. No new visible binding/expression error was observed during captured navigation; measured CDP diagnostic scope is recorded separately and is not a claim that all Gateway logs are error-free. Source-health change is data-driven; no status expression was modified. The pre-existing invalid-data gauge fallback behavior remains outside this design-preserving change; good live values now feed the selected detail gauges.

Outstanding: four SP semantics/unit decisions; disabled alarm/history/physical-status operational validation; UNICORN View/identity/channel/unit gates; permanent licensing and independent Acropolis review. No full-site deployment, UDT redesign, process calibration, equipment operation or formal witnessed SAT acceptance is claimed.

## Rollback and evidence

[Architecture](01_Existing_UDT_Architecture_Report.md), [comparison](02_UDT_Configuration_Comparison.csv), [baseline manifest](03_FAT_Baseline/baseline-manifest.json), [authorized set](04_Approved_Change_Set.json), [12-row end-to-end evidence](05_End_to_End_Verification.csv), [rollback procedure](08_Rollback/Targeted_Rollback_Procedure.md), [UNICORN plan](09_UNICORN_Integration_Change_Plan.md).

Rollback is targeted at the original properties/overrides, not a Gateway restore. STIRR's original memory source/literal is retained and restored only after confirming memory mode and disabled state. Configuration roundtrip and six isolated mocked guard cases passed; no live fault was forced and no production rollback is falsely claimed. Protected credential-bearing backups remain outside the workspace under `C:\TBMC\Secure\TBMC-COM-06A-20261126-0224`. Native archive CRC checks and final artifact hashes are separately indexed. No credentials were published or committed and no external message/upload was sent.

[Acceptance and untested criteria](Acceptance_and_Untested_Criteria.csv) distinguishes preservation/acquisition passes from disabled alarm/history/operating-state tests. [Recovery custody](evidence/recovery-and-final-custody.json) records archive verification and retained guard source. A diagnostic Perspective session later timed out; fresh authenticated regression/navigation captures were obtained without OPC-quality loss. The earlier literal RuntimeExceptions placeholder is excluded from proof; use measured counters in [UI runtime diagnostics](evidence/ui-runtime-diagnostics.json).
