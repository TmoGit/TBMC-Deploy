def handleTimerEvent():
    import json,codecs,traceback,os
    root='[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01'
    statePath='C:/TBMC/Logs/TBMC-COM06A-Pilot-Guard.json'
    secure='C:/TBMC/Secure/TBMC-COM-06A-20261126-0224'
    try:
        if os.path.exists(secure+'/pilot-guard-completed'):return
        if os.path.exists(secure+'/pilot-guard-review-handoff'):
            with codecs.open(statePath,'w','utf8') as f:json.dump({'Status':'HANDOFF_STOPPED_BY_REVIEWER','UTC':system.date.format(system.date.now(),"yyyy-MM-dd'T'HH:mm:ss.SSSXXX")},f)
            return
        with codecs.open(secure+'/guard-approved-change-set.json','r','utf8') as f:approval=json.load(f)
        with codecs.open(secure+'/guard-targeted-rollback-payload.json','r','utf8') as f:rollback=json.load(f)
        names=['TEMP','pH','pO2','AFOAMT','BASET','SUBS_A','SUBS_B','SUBS_C','VWEIGHT','JTEMP','AIROV','STIRR','KeyCPP1','KeyCPP2','KeyCPP3']
        record={'UTC':system.date.format(system.date.now(),"yyyy-MM-dd'T'HH:mm:ss.SSSXXX"),'Status':'ACTIVE_QUALITY_AND_APPROVED_SOURCE_GUARD','Root':root,'NoOPCWritesOrMethodCalls':True,'ParameterCount':12}
        if not system.tag.exists(root) or not all(system.tag.exists(root+'/'+n) for n in names):
            record['Status']='MANUAL_REVIEW_INSTANCE_OR_MEMBER_MISSING_NO_RECREATION'
            with codecs.open(statePath,'w','utf8') as f:json.dump(record,f,indent=2)
            return
        values=system.tag.readBlocking([root+'/'+n for n in names]);changes=approval['Changes'];props=system.tag.readBlocking([c['TagPath']+'.'+c['Property'] for c in changes]);bad=[n for n,q in zip(names,values) if not q.quality.isGood() or 'NoData' in str(q.quality) or q.value is None];drift=[c['TagPath']+'.'+c['Property'] for c,q in zip(changes,props) if not q.quality.isGood() or str(q.value)!=str(c['Proposed'])]
        if bad or drift:
            record.update({'Status':'ROLLING_BACK','BadMembers':bad,'SourceConfigurationDrift':drift})
            with codecs.open(statePath,'w','utf8') as f:json.dump(record,f,indent=2)
            qs=system.tag.configure(root,rollback['Tags'],'m');record['RollbackResults']=[str(q) for q in qs];assert all(q.isGood() for q in qs)
            for t in rollback.get('MemoryValueRestorationAfterSourceIsMemoryAndDisabled',[]):
                check=system.tag.readBlocking([root+'/'+t['name']+'.valueSource',root+'/'+t['name']+'.enabled']);assert str(check[0].value)=='memory' and not check[1].value
                qs=system.tag.configure(root,[t],'m');assert all(q.isGood() for q in qs)
            check=system.tag.readBlocking([c['TagPath']+'.'+c['Property'] for c in changes]);record['OriginalSourcePropertiesRestored']=all(q.quality.isGood() and str(q.value)==str(c['Original']) for c,q in zip(changes,check));assert record['OriginalSourcePropertiesRestored']
            record['Status']='BASELINE_SOURCE_RESTORED_AFTER_QUALITY_OR_CONFIGURATION_FAILURE';open(secure+'/pilot-guard-completed','w').write(record['UTC'])
            system.tag.exportTags(filePath=secure+'/guard-restored-instance.json',tagPaths=[root],recursive=True,exportType='json')
        with codecs.open(statePath,'w','utf8') as f:json.dump(record,f,indent=2)
    except:
        with codecs.open(statePath,'w','utf8') as f:json.dump({'Status':'GUARD_ERROR_RETRY_NEXT5SEC','UTC':system.date.format(system.date.now(),"yyyy-MM-dd'T'HH:mm:ss.SSSXXX"),'ErrorType':str(__import__('sys').exc_info()[0])},f)
