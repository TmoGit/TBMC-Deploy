# UNICORN integration plan — assessment only

Existing example: `[default]TBMC-SCADA/TW-LAB01/Gene_Therapy-815/DOWNSTREAM/CHROMATOGRAPHY/AVA25`, typeAVANT_CHROM_SKID. Parent, instance, source modes, memory Flow Rate, addresses, alarms, history, status, permissions and UI remain unchanged.

Six source requirements are pH, Conductivity, Flow Rate, UV Absorbance, Pressure and Gradient. Existing references use Sample_Device; candidate addresses on Unicorn-2/Avant3119961 are preserved in the previous OPC verification matrix/inventory. pH→RunData/pH, Conductivity→Cond, Flow Rate→System flow and Pressure→System pressure are review candidates. UV1/2/3 and ConcB/%Cond require explicit channel/gradient decisions. No current asset serial-to-folder association is inferred from the example.

Prerequisites: separately approve and verify View-mode monitoring, confirm the actual asset identity, resolve user-scoped Default addresses if migrating to Ignition_User, obtain valid non-NoData process values and confirm units/semantics. Flow ml/min versus existing lpm requires an approved conversion; preserve data types and all existing structure. Do not bind current Good_NoData sentinel values as live process measurements.

Only after those gates, prepare per-member instance overrides of valueSource/opcServer/opcItemPath and any explicitly approved necessary enabled flags; retain all other effective properties and original override provenance. Inspect existing simulation writers and downstream alarms/history before deployment. Take a fresh supported backup/export, targeted rollback and approved window; start with a small proven subset on the same existing instance.

**No ConnectSystem call, ConnectSystemTag write, AssignState change, process method/manual instruction, credential or certificate change occurred in Commission06A.** The preceding `../opc-verification/UNICORN_Initialization_Assessment.md` contains exact parent/method/tag identifiers and the separately approval-gated procedure. This plan does not authorize initialization or chromatography source changes.

The unchanged [original OPC verification package](reference/TBMC-OPC-Verification-20261126-Upload.zip) is included for source identifiers and initialization evidence.
