# Commission06B — Room815 UNICORN

**Outcome: BLOCKED before instrument initialization and live tag deployment.** Read-only assessment completed on 26 November2026, Asia/Taipei. OPC authentication/browsing succeeded, but no valid live chromatography measurements or View assignment were established. Zero production configuration properties changed; zero instrument methods, trigger writes, process instructions or control commands executed. Both MFCS Twins remain enabled/live and unchanged.

## Actual barriers

1. **Asset association discrepancy:** supplied Design Specification inventory lists Room815 Avant25 at172.16.81.69 and Repligen TFF at172.16.81.70. Current DNS resolves815-avant25-01 to172.16.81.70, the configured UNICORN OPC endpoint; current address space has Avant3119961/Default. Separate instrument/workstation addresses or stale inventory could explain this, but neither was assumed. TBMC reconciliation was requested; physical/SCADA association is not claimed verified.
2. **Operator/session safety gate:** manual29752660 p29 documents ConnectSystem and p68 describes default View. However, p39 warns against multiple OPC clients on one system and that disconnecting one user disconnects the others. Actual AssignState, RunState and UserInControl are Good_NoData, so no-other-client/owner safety cannot be established from these values. TBMC confirmation of exclusive OPC use and authorization for one zero-input ConnectSystem plus conditional Disconnect was requested. No reply was received at report generation, and no dependent operation was executed.
3. **Data unavailable:** all eight process candidates for six customer members retain Good_NoData, raw UA **0x00A50000**, throughout 90.001 seconds. UV=-6000 and pressure=-1 are placeholders, and zero values with NoData are not actual process measurements. Instrument operating state is unknown; no claim is made that a customer run is required until safe View initialization has been performed and idle data re-evaluated.

The active connection readOnly=True protection is unchanged. No Call was attempted, so rejection of supported callMethod by read-only mode is not asserted. No direct SDK Call bypass, unrestricted-write change, trigger-tag fallback or retry loop was used. Any temporary protection change requires separate narrow approval if later proven necessary.

## Evidence and completed assessment

Fresh protected Gateway backups, full native default-provider exports and TBMC project exports were captured before and after the read-only work. Existing Room815 AVA25 path and AVANT_CHROM_SKID type were verified; native effective configuration and active SDK property inheritance/extension/local-presence evidence are included. Flow Rate is an existing disabled memory tag. All six process members and three references remain disabled. Administrative EquipIsEnabled is already enabled/True/Good and displayed1; no administrative write was needed. KeyCPP1/2/3 remain Conductivity, Flow Rate and Pressure.

Unicorn-2 is CONNECTED using existing username authentication, Basic256Sha256/SignAndEncrypt. Current NamespaceArray identifies the expected server hostname and DataAccess URI at index2. Actual ConnectSystem and Disconnect methods/parents were browsed, no arguments were advertised, and raw Executable/UserExecutable both returned true/Good. This metadata does not establish a successful invocation or override the identity/session gates. Recovery is documented in manualp38, subject to p39's shared-disconnect warning. AssignState's0=View/1=Control/2=None/3=Disconnected enumeration is distinct from ConnectSystemTag0=None/1=ConnectSystem. Only the latter trigger's0 value had raw Good status; it does not prove View mode.

Gateway Quick Client renders these unavailable process values as broad “Good”. The read-only native SDK and raw UA attributes expose the NoData diagnostic and exact numeric code, preventing a false live-data claim. Four samples at0/30/60/90seconds retain separate raw source/server timestamps; process source timestamps remain from the prior unavailable sample. Static real values would be acceptable with valid quality; these are rejected for NoData, not for being static.

A fixed one-shot, read-only diagnostic project was temporarily imported to collect exact UA Read results and active property metadata, then deleted. It contained no Call, Write, source configuration, rollback or reconnect operation. Existing project resources were untouched. Its source, import/retirement evidence and marker-bound single execution are retained. No ongoing instrumentation, automatic rollback or reconnect project remains.

## Parameter reconciliation

| Existing member | Candidate | Units / decision |
|---|---|---|
|pH|RunData/pH|Dimensionless; quality unavailable|
|Conductivity|RunData/Cond|mS/cm compatible; source Float to existing Float8 preserved if eligible|
|Flow Rate|RunData/System flow|ml/min vs existing lpm; approved verified scaling needed; no conversion applied|
|UV Absorbance|RunData/UV1,2,3|All mAU; required channel/wavelength unresolved; none selected|
|Pressure|RunData/System pressure|Source MPa physically compatible with existing(Mpa); no bar conversion invented|
|Gradient|RunData/Conc B|% candidate buffer-B composition; required semantics need confirmation; no %Cond substitution|

Every candidate remains ineligible due NoData. No units, datatypes, ranges, thresholds, bindings or parent UDT properties were changed. Full records are in04_UNICORN_OPC_Verification.csv,05_Run_State_Data_Availability.csv and06_Customer_Parameter_Mapping.csv.07_Approved_Change_Set.json explicitly contains no approved executable changes.

## Screens and preservation

Original Gene Therapy815 overview, AVA25 detail and final administrative enablement screenshots are in10_SCADA_Evidence/. They show the preserved unavailable acquisition; there is no fabricated “after successful integration” screenshot. The captured-diagnostics HTML/PNG is explicitly a static rendering of raw read evidence, not a replacement SCADA view. Detail navigation/image/gauges were inspected, but live matching cannot be tested while source data is unavailable. Existing alarm-editor default controls were not saved and are not evidence that actual alarm definitions are enabled. Disabled history and alarm configurations were preserved; functional tests were not performed.

![Both MFCS Twins remain live](10_SCADA_Evidence/plasmid-814-mfcs-both-live.png)

09_Configuration_Diff.json proves **zero production property changes**, the same1839 provider nodes, unchanged parent definitions/hierarchy,494 unchanged TBMC resource files, all existing projects unchanged, all stored configuration resources unchanged, both MFCS integrations unchanged and all unrelated chromatography instances unchanged, including Plasmid814 AVA25/AVA150. The final read-only samples show12 process members and3CPP references Good per Twin, administrative True/Good. No forced active/running/in-use/batch/health/color or alarm indication occurred.

## Final disposition and acceptance

Room815 AVA25 retains original source/member configuration, administrative monitoring True, and zero transitioned live parameters. Unicorn-2 remains connected/read-only; no confirmed instrument View assignment exists. Both MFCS vessels remain enabled/live. Native trial observation: 2026-11-25T21:08:00.320Z; Ignition trial active=True, 2448 seconds remaining at that snapshot. No license/trial/certificate/authentication/service changes or Gateway restart occurred.

Acceptance: **8PASS, 5BLOCKED, 2NOT TESTED**; each criterion is listed in Acceptance_Criteria.csv. The chromatography integration is not passed. Supported native archive CRC checks passed, but no full restore/restart persistence test was performed; previous backup/runtime representation limitations remain, so full native provider exports are retained separately and protected. No production rollback was needed or executed.

## Exact next work after gates clear

Reconcile the current asset/workstation/Room815 association with TBMC. Confirm no conflicting OPC user/client and safe operator-approved conditional recovery. Recheck method metadata/state and invoke only the documented ConnectSystem through supported system.opcua.callMethod using current namespace resolution and an empty input list, if still appropriate and specifically authorized. Never set AssignState1, automatically write ConnectSystemTag, weaken protections without approval, retry automatically or disconnect others. Verify raw Good AssignState0 and no control acquisition before accepting monitoring. If unavailable data persists in confirmed View/idle mode, arrange observation during a TBMC-operated run without initiating one. Then reconcile UV channel, gradient requirement and any approved Flow Rate scaling, approve exact minimal instance patches/rollback, and verify source→UDT→existing displays. Production hardening must separately define authentication-context addresses, session loss, owner-safe reconnect/disconnect and permanent licensing. No retry mechanism is deployed by this commission.

Technical interface reference: [supported Ignition callMethod](https://www.docs.inductiveautomation.com/docs/8.3/appendix/scripting-functions/system-opcua/system-opcua-callMethod); [read-only connection settings](https://www.docs.inductiveautomation.com/docs/8.3/ignition-modules/opc-ua/opc-ua-connections). Vendor behavior and warnings above are from the supplied local manuals, whose hashes/page extracts are included.
