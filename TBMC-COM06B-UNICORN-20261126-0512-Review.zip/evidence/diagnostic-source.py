def handleTimerEvent():
    from java.io import File
    if not File('C:/TBMC/Secure/TBMC-COM-06B-20261126/one-shot-readonly.lock').createNewFile():return
    import json,codecs,time,traceback
    from java.io import File
    RUN='C:/Users/user/Desktop/TBMC-Deploy-main/artifacts/controlled-unicorn-integration-06B'
    SECURE='C:/TBMC/Secure/TBMC-COM-06B-20261126'
    out={'Scope':'Fixed one-shot read-only diagnostics: no OPC writes, no Call service, no tag configuration, no connection modifications','Started':system.date.format(system.date.now(),"yyyy-MM-dd'T'HH:mm:ss.SSSXXX"),'Samples':[],'Errors':[]}
    def save():
     with codecs.open(RUN+'/evidence/exact-quality-and-initialization-gates.json','w','utf8') as f:json.dump(out,f,indent=2)
    def now():return system.date.format(system.date.now(),"yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    def quality(q):
     try:return {'Text':str(q),'Code':int(q.getCode()),'Diagnostic':str(q.getDiagnosticMessage())}
     except:return {'Text':str(q)}
    try:
     from com.inductiveautomation.ignition.gateway import IgnitionGateway
     from com.inductiveautomation.ignition.common.tags.paths.parser import TagPathParser
     from java.lang import Class
     from org.python.core import Py
     from java.util.concurrent import TimeUnit
     gateway=IgnitionGateway.get();c=gateway.getOpcManager().getConnection('Unicorn-2')
     out['ConnectionMethods']=[str(m.getName()) for m in c.getClass().getMethods() if any(x in str(m.getName()).lower() for x in ['readonly','config','method'])]
     out['ConnectionReadOnly']={}
     for n in ['isReadOnly','getReadOnly']:
      try:out['ConnectionReadOnly'][n]=bool(getattr(c,n)())
      except:pass
     managed=getattr(c,'getManagedClient$opc_ua_gateway')();assert managed.getInitialized();client=managed.get(None);loader=Class.getClassLoader(client.getClass())
     def cls(name):return Py.java2py(loader.loadClass(name))
     NodeId=cls('org.eclipse.milo.opcua.stack.core.types.builtin.NodeId');QualifiedName=cls('org.eclipse.milo.opcua.stack.core.types.builtin.QualifiedName');uint=cls('org.eclipse.milo.opcua.stack.core.types.builtin.unsigned.Unsigned').uint;ReadValueId=cls('org.eclipse.milo.opcua.stack.core.types.structured.ReadValueId');TimestampsToReturn=cls('org.eclipse.milo.opcua.stack.core.types.enumerated.TimestampsToReturn')
     ns=list(system.opc.readValue('Unicorn-2','ns=0;i=2255').value);out['NamespaceArray']=[str(v) for v in ns];index=ns.index('http://opcfoundation.org/OPC/DataAccess')
     spec=json.load(codecs.open(RUN+'/evidence/prior-selected-nodes.json','r','utf8'));nodes=spec['Nodes'];out['RawMetadata']=[]
     def nodeid(uri):return NodeId.parse('ns='+str(index)+';'+uri.split(';',1)[1])
     def rawRead(pairs):
      req=[ReadValueId(nodeid(p),uint(a),None,QualifiedName.NULL_VALUE) for p,a in pairs];res=client.read(0.0,TimestampsToReturn.Both,req);res=res if hasattr(res,'getResults') else res.get(20,TimeUnit.SECONDS);ans=[]
      for (p,a),dv in zip(pairs,res.getResults()):
       v=dv.getValue().getValue();status=dv.getStatusCode();ans.append({'NodeId':p,'AttributeId':a,'Value':str(v),'StatusCode':str(status),'StatusCodeNumeric':long(status.getValue()),'SourceTimestamp':str(dv.getSourceTime()),'ServerTimestamp':str(dv.getServerTime())})
      return ans
     pairs=[]
     for n in spec['Methods']:
      if n['Type']=='METHOD':
       for attr in [2,3,21,22]:pairs.append((n['NodeId'],attr))
     for n in nodes:
      for attr in [3,14,17,18]:pairs.append((n['NodeId'],attr))
     out['RawMetadata']=rawRead(pairs)
     # Capture active SDK local/inherited metadata without importing or changing it.
     provider=gateway.getTagManager().getTagProvider('default');p=TagPathParser.parse('[default]TBMC-SCADA/TW-LAB01/Gene_Therapy-815/DOWNSTREAM/CHROMATOGRAPHY/AVA25');models=provider.getTagConfigsAsync([p],True,False).get(20,TimeUnit.SECONDS);prov=[]
     def walk(m):
      entry={'Path':str(m.getPath()),'Type':str(m.getType()),'Properties':[]}
      for prop in m.getProperties():
       name=str(prop.getName())
       if name in ['enabled','valueSource','opcServer','opcItemPath','historyEnabled','sourceTagPath','dataType','engUnit','alarms','scaleMode','rawLow','rawHigh','scaledLow','scaledHigh']:
        entry['Properties'].append({'Name':name,'Value':str(m.getOrDefault(prop)),'Inherited':m.isInherited(prop),'Extended':m.isExtended(prop),'LocalContains':m.getLocalConfiguration().contains(prop)})
      prov.append(entry)
      for ch in m.getChildren():walk(ch)
     for m in models:walk(m)
     with codecs.open(RUN+'/01_Baseline_Configuration/active-inheritance-provenance.json','w','utf8') as f:json.dump({'Scope':'Read-only active SDK model, no mutations','Nodes':prov},f,indent=2)
     out['OPCState']={server:str(system.opc.getServerState(server)) for server in ['Unicorn-2','MFCS_OPCUA']};save()
     start=time.time()
     for offset in [0,30,60,90]:
      remain=start+offset-time.time()
      if remain>0:time.sleep(remain)
      sample={'Observed':now(),'ElapsedSeconds':time.time()-start,'QualifiedReadings':[],'RawValues':rawRead([(n['NodeId'],13) for n in nodes]),'Equipment':[]}
      for n,q in zip(nodes,system.opc.readValues('Unicorn-2',[n['NodeId'] for n in nodes])):sample['QualifiedReadings'].append({'Name':n['Name'],'NodeId':n['NodeId'],'Value':str(q.value),'Quality':quality(q.quality),'Timestamp':system.date.format(q.timestamp,"yyyy-MM-dd'T'HH:mm:ss.SSSXXX")})
      roots=[('[default]TBMC-SCADA/TW-LAB01/Gene_Therapy-815/DOWNSTREAM/CHROMATOGRAPHY/AVA25',['pH','Conductivity','Flow Rate','UV Absorbance','Pressure','Gradient','KeyCPP1','KeyCPP2','KeyCPP3','Status/EquipIsEnabled']),('[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01',['TEMP','pH','pO2','AFOAMT','BASET','SUBS_A','SUBS_B','SUBS_C','VWEIGHT','JTEMP','AIROV','STIRR','KeyCPP1','KeyCPP2','KeyCPP3','Status/EquipIsEnabled']),('[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-02',['TEMP','pH','pO2','AFOAMT','BASET','SUBS_A','SUBS_B','SUBS_C','VWEIGHT','JTEMP','AIROV','STIRR','KeyCPP1','KeyCPP2','KeyCPP3','Status/EquipIsEnabled'])]
      for root,members in roots:
       vals=system.tag.readBlocking([root+'/'+n for n in members]);sample['Equipment'].append({'Root':root,'Members':[{'Name':n,'Value':str(q.value),'Quality':quality(q.quality)} for n,q in zip(members,vals)]})
      out['Samples'].append(sample);save()
     out['Finished']=now();out['Outcome']='READ_ONLY_ASSESSMENT_COMPLETE';save()
    except:
     out['Errors'].append(traceback.format_exc()[-2500:]);out['Outcome']='READ_ONLY_ASSESSMENT_ERROR';save()
