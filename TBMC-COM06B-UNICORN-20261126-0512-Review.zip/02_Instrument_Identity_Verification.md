# Room815 instrument and SCADA association

Expected existing instance is [default]TBMC-SCADA/TW-LAB01/Gene_Therapy-815/DOWNSTREAM/CHROMATOGRAPHY/AVA25, type AVANT_CHROM_SKID. Both path and type are verified from a fresh native export. Existing image is Cytiva_Avant; KeyCPP references are Conductivity, Flow Rate and Pressure.

Unicorn-2 is enabled and CONNECTED, authenticated using the existing username context, Basic256Sha256 / SignAndEncrypt, with readOnly=True. No authentication or certificate settings were changed. Endpoint is opc.tcp://815-avant25-01:60409/OPC/DAAndAEServer. DNS resolves 815-avant25-01 to 172.16.81.70. Current UA NamespaceArray includes urn:815-avant25-01:UA:OPCDAAndAEServer, and current browse identifies Avant3119961 in Default context. This verifies the expected OPC server/address-space identity, not an independently witnessed physical asset serial number.

The supplied Digital Design Specification inventory contains these exact rows:

| Equipment | IP | Area |
|---|---|---|
| Cytiva Äkta Avant25 |172.16.81.69|815 - Gene Therapy|
| Repligen Krosflo KR2i TFF |172.16.81.70|815 - Gene Therapy|

Source SHA256: ff61e05a795375a08bd44dd1525b439195914c7cc6c8d509b6d29ba57ea3f53a. See evidence/inventory-conflicting-rows.json. The current source association and inventory require reconciliation. Separate instrument/workstation addresses or an obsolete inventory could explain the difference; neither explanation was assumed. The user was asked for the current confirmed asset/workstation association. No instrument initialization or tag binding was attempted while that gate is unresolved. AC-01 is BLOCKED for full physical/SCADA association.
