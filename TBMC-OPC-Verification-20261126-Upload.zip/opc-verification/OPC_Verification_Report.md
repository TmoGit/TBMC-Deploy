# TBMC OPC UA data source verification and parameter mapping

TBMC-COM-OPC-VERIFY-01 • 26 November2026 • Diagnostic evidence and non-deployed proposal • Human review PENDING

## Executive result

Two existing connections are CONNECTED. Discovered **1560 unique in-scope nodes** across MFCS U01/U02/U03 and UNICORN Avant3119961, including metadata and configuration objects; 239 are categorized process measurements and 30 trend-array nodes. Separate diagnostics inventory prevents counting methods/configuration as process parameters.

Following your clarification, requirements come from the **Ignition Tag Browser**, using one representative5L bioreactor and one AVANT chromatography example. **22 example requirements evaluated:16 bioreactor +6 AVANT.** Each has one or more discovered address candidates. All16 bioreactor candidates return valid Good data on both U01 and U02. All9 AVANT candidate channels for6 requirements remain Good_NoData. UV channel and Gradient meaning are ambiguous. No approved physical equipment-to-folder association was supplied; therefore **zero production/physical-asset mappings are verified or import-eligible**. Model/name/unit matching does not identify a particular skid.

## Selected project requirements and sources

- `[default]TBMC-SCADA/TW-LAB01/Plasmid-814/UPSTREAM/BIOREACTORS/BRX5-02-01`, type `5L_BIOREACTOR`:16 process leaves. KeyCPP display aliases/status metadata are not counted as independent requirements.
- `[default]TBMC-SCADA/TW-LAB01/Gene_Therapy-815/DOWNSTREAM/CHROMATOGRAPHY/AVA25`, type `AVANT_CHROM_SKID`:6 process leaves. STIRR and Flow Rate are memory-source project tags with retained sample addresses, not real acquisition.

The user selected representative examples instead of asserting a physical equipment assignment. Native default-provider export preserves exact names, units, data types, addresses, source types and history flags; [requirements with JSON pointers](evidence/customer-example-requirements.json), [sanitized existing OPC definitions](evidence/project-opc-tag-definitions.json). Original export/backup remain protected. The worksheet `工作表1` of TBMC PAD Ignition Equipment list.xlsx is an inventory, not a per-parameter list; its5L count18 and AVANT count30 differ from selected16/6 and are retained as unresolved source differences. Workbook row32 assigns172.16.81.70 to Repligen, while the commission names that IP as UNICORN; current actual endpoint uses hostname815-avant25-01. No IP/address inventory conflict was silently repaired.

Manuals: `29752660.pdf`, UNICORN OPC Server1.3 User Manual29752660 AA,122pages; `29800665.pdf`, UNICORN7.12 Administration and Technical Manual,236pages. Primary interpretation uses actual installed namespace, supplied manual§§2.5/2.7.1/4.1/4.5 and [Ignition8.3 readValues](https://www.docs.inductiveautomation.com/docs/8.3/appendix/scripting-functions/system-opc/system-opc-readValues), [browseServer](https://docs.inductiveautomation.com/docs/8.3/appendix/scripting-functions/system-opc/system-opc-browseServer), and [callMethod](https://www.docs.inductiveautomation.com/docs/8.3/appendix/scripting-functions/system-opcua/system-opcua-callMethod). Attached manuals provide technical evidence, not authorization to execute the control operations illustrated in them.

## Connectivity and discovery

MFCS_OPCUA actual discovery/endpoint: `opc.tcp://814-dcu-m-bial:4842/BioPAT_MFCS`; Anonymous, securityNone/None. Namespace `http://www.sartorius.com/BioPAT_MFCS_OPC_Server/Units`; U01=Biostat B TWIN_L_814/BIOSTAT B Twin, U02=Biostat B TWIN_R_814/BIOSTAT B Twin, U03=Satoflow Smart_814/SARTOFLOW Smart. Uptime at initial capture about1h44m. U03 is not a bioreactor; no bioreactor tag template was assigned to it.

Unicorn-2 actual discovery/endpoint: `opc.tcp://815-avant25-01:60409/OPC/DAAndAEServer`; username authentication, Basic256Sha256/SignAndEncrypt. Instrument Avant3119961. DataAccess namespace currently2; URI-based addresses used successfully for reads/subscriptions. Initial connection uptime about23m. Credential contents were neither decrypted nor exported. No authentication experiment using Ignition_User occurred.

Authenticated initial/final Gateway captures record connectivity and trial state. Trial had about1h42m left initially and stayed active during tests; no reset was performed by this commission. Permanent licensing is not proven. Bounded browse used only these existing connections, max2500 calls per task/depth10 and80ms pause; original and Event supplement both completed without truncation. No disabled server was browsed/enabled. UNICORN Event was initially excluded too broadly, then correctly included after manual4.1 identified RunData/PictureData as process data. Intermediate attempts and correction provenance are retained.

## Live verification

Bounded monitoring 2026-11-26T01:53:42.711+08:00 to 2026-11-26T01:54:42.757+08:00; approximately60sec, samples at0/20/40/60sec.55 temporary scalar OPC subscription tags, history disabled, no event scripts, write permissions denied; all removed afterward. Both direct reads and subscription snapshots retained, totaling440 monitoring rows. Initial bulk read evidence is separate, including metadata/configuration values; these do not inflate process coverage.

U01/U02:16 example candidate nodes each valid Good at final read and subscription. Unchanged process values are not failures; no process run was initiated. U03:9 observed process values Bad; connected OPC session does not prove underlying SARTOFLOW data readiness. UNICORN:9 process candidate channels +5 status fields remain Good_NoData. Numeric0, UV-6000 and pressure-1 are not accepted as valid process readings. `quality.isGood()` alone is insufficient because Good_NoData is good-severity. Source-preferred timestamps and observations are retained, but independent raw source/server timestamp pairs, raw UA access attributes and qualified BrowseName are not exposed by the supported scripting objects. No unsupported attribute values or write-access claims are invented. Static value alone is not classified stale; no approved age threshold supplied.

## Example reconciliation

| Project example | Customer parameter | OPC units | Classification |
|---|---|---|---|
|AVA25|pH||INITIALIZATION_REQUIRED|
|AVA25|Conductivity|mS/cm|INITIALIZATION_REQUIRED|
|AVA25|Flow Rate|ml/min|INITIALIZATION_REQUIRED|
|AVA25|UV Absorbance|mAU|AMBIGUOUS_MATCH|
|AVA25|Pressure|MPa|INITIALIZATION_REQUIRED|
|AVA25|Gradient|%|AMBIGUOUS_MATCH|
|BRX5-02-01|TEMP|°C|CANDIDATE_MATCH|
|BRX5-02-01|SUBS_B|%|CANDIDATE_MATCH|
|BRX5-02-01|pH|pH|CANDIDATE_MATCH|
|BRX5-02-01|CO2SP|lpm|CANDIDATE_MATCH|
|BRX5-02-01|SUBS_A|%|CANDIDATE_MATCH|
|BRX5-02-01|O2SP|lpm|CANDIDATE_MATCH|
|BRX5-02-01|AFOAMT|ml|CANDIDATE_MATCH|
|BRX5-02-01|SUBS_C|%|CANDIDATE_MATCH|
|BRX5-02-01|pO2|%sat|CANDIDATE_MATCH|
|BRX5-02-01|N2SP|lpm|CANDIDATE_MATCH|
|BRX5-02-01|VWEIGHT|kg|CANDIDATE_MATCH|
|BRX5-02-01|STIRR|rpm|CANDIDATE_MATCH|
|BRX5-02-01|JTEMP|°C|CANDIDATE_MATCH|
|BRX5-02-01|AIROV|%|CANDIDATE_MATCH|
|BRX5-02-01|AIRSP|lpm|CANDIDATE_MATCH|
|BRX5-02-01|BASET|ml|CANDIDATE_MATCH|

Classification counts: {'INITIALIZATION_REQUIRED': 4, 'AMBIGUOUS_MATCH': 2, 'CANDIDATE_MATCH': 16}. The [CSV matrix](Customer_Parameter_Mapping.csv) contains every candidate NodeId/path, source tag, original placeholder, units, quality, proposed address, confidence and open decision. VerifiedOPCNodeId remains blank until the physical/semantic association is approved; exact discovered candidates are populated separately. [Coverage by instrument](Coverage_By_Instrument.csv) separates address presence, candidate live availability and approved mapping coverage. This is representative-example coverage, not full customer/site coverage or SAT readiness.

## Existing mapping and corrections

All22 example source references point to `Ignition OPC UA Server` / Sample_Device placeholders; current loopback connection is disabled. Two example values are memory sources. Do not replace them in this commission. CO2SP uses projectccm vs OPC lpm (review factor1000); AVANT Flow Rate projectlpm vs OPC ml/min (review divide1000). Pressure spellingMpa/MPa is normalized naming, not evidence of a scale conversion. pH projectunits unset; MFCS exposespH. MFCS serverDouble versus projectFloat4 narrowing needs review. SP-suffixed controller names expose separate Value/Setpoint fields; intended read semantics must be confirmed, never write a setpoint here. UV1/2/3 and ConcB/%Cond require channel/process decisions.

History flags/provider properties are recorded as intended configuration only. They do not prove a historian measurement/field destination or successful history. No historian write was performed. [Proposed tag JSON](Proposed_Ignition_Tag_Mapping.json) has an empty import-ready tags array and separately labeled disabled native-format review candidates; unresolved mappings are excluded from production import.

## Initialization, deficiencies and next commission

See [UNICORN initialization assessment](UNICORN_Initialization_Assessment.md) for exact parent/method/tag identifiers, discovered ConnectSystemTag enumeration0=None/1=ConnectSystem, View0 versus forbidden Control1, supported Gateway/Perspective call mechanism and approval-gated follow-on. No initialization was executed and recovery is unproven. Default user context appears in NodeIds; migration to a dedicated identity requires revalidation.

[Deficiency register](OPC_Mapping_Deficiencies.csv) records10 issues, including asset association, placeholders, unavailable UNICORN/SARTOFLOW data, units/channels, raw-metadata limitations and inventory discrepancies. Recommended next commission: **TBMC-authorized UNICORN View-only initialization and equipment-identity/channel/unit confirmation**, followed by another read/subscription verification. Approve tag deployment and historian integration separately after those gates. Connectivity/browse alone does not establish SAT readiness.

## Change boundary and custody

Production tags and project source were not edited; existing OPC credentials/configurations, security, firewalls, licensing and services were not changed. No OPC writes, server method calls, alarm acknowledgment, instrument control or run occurred. Only an owned temporary diagnostic Gateway project and55 history-disabled subscription tags were created, with protected supported native backups, then removed. [Preservation and cleanup](evidence/preservation-and-cleanup.json) records comparisons and archive CRC checks; no live restore was attempted. Protected credential-bearing archives remain under `C:\TBMC\Secure\TBMC-OPC-VERIFY-20261126`, excluded from deliverables. No external messages, source commits or uploads were performed.

[Primary process inventory](OPC_Process_Parameter_Inventory.json) excludes methods/configuration/metadata. [Temporal summary](Observed_Temporal_Summary.csv) records initial/final quality, value changes and timestamp advance per monitored node; live-evidence CSV includes observed-minus-qualified-timestamp ages. No unapproved staleness threshold was applied. [Source hashes and user clarifications](evidence/source-manifest.json). Gas-flow conversion factors require matching reference conditions and process-owner approval.
