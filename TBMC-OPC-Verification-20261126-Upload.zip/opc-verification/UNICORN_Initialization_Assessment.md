# UNICORN initialization assessment — not executed

26 November2026; OPC Server1.3 manual29752660 AA and UNICORN7.12 administration manual29800665 supplied. No OPC writes, method calls, control acquisition, run, alarm acknowledgement, credential/certificate/policy/license/service change was performed.

The server session is connected, but instrument assignment is not established. Direct and subscribed diagnostics retain AssignState2/None, InstrumentStatus2/Unknown and InstrumentStatusConnection0/Yes with **Good_NoData**. Those values are not valid live status proof. RunData has Good_NoData, including defaults0, UV-6000 and pressure-1. Do not display these as actual measurements. Manual29752660 §2.7.1 p29 requires ConnectSystem to connect the client to the instrument. §4.5.1 pp68–69 documents default View and states0 View/1 Control/2 None/3 Disconnected. §§4.5.4–5 pp74–77 require valid instrument connection/status. This supports initialization as the next investigation gate; no causal recovery is proven until separately authorized execution.

## Actual discovered addressing

| Node | Exact namespace-URI address | API datatype |
|---|---|---|
|ConnectSystemTag|`nsu=http://opcfoundation.org/OPC/DataAccess;s=1:Avant3119961?ConnectSystemTag?Default\ConnectSystemTag`|<type 'java.lang.Integer'>|
|Disconnect Tag|`nsu=http://opcfoundation.org/OPC/DataAccess;s=1:Avant3119961?DisconnectTag?Default\Disconnect Tag`|<type 'java.lang.Integer'>|
|AssignState|`nsu=http://opcfoundation.org/OPC/DataAccess;s=1:Avant3119961?AssignState?Default\AssignState`|<type 'java.lang.Integer'>|
|InstrumentStatus|`nsu=http://opcfoundation.org/OPC/DataAccess;s=1:Avant3119961?InstrumentStatus?Default\InstrumentStatus`|<type 'java.lang.Integer'>|
|InstrumentStatusConnection|`nsu=http://opcfoundation.org/OPC/DataAccess;s=1:Avant3119961?InstrumentStatusConnection?Default\InstrumentStatusConnection`|<type 'java.lang.Integer'>|
|RunState|`nsu=http://opcfoundation.org/OPC/DataAccess;s=1:Avant3119961?RunState?Default\RunState`|<type 'java.lang.String'>|
|UserInControl|`nsu=http://opcfoundation.org/OPC/DataAccess;s=1:Avant3119961?UserInControl?Default\UserInControl`|<type 'java.lang.String'>|

ConnectSystem parent ObjectId: `nsu=http://opcfoundation.org/OPC/DataAccess;s=1:Avant3119961?ConnectSystem?Default`

ConnectSystem MethodId: `nsu=http://opcfoundation.org/OPC/DataAccess;s=1:Avant3119961?ConnectSystem?Default\ConnectSystem`

Disconnect parent ObjectId: `nsu=http://opcfoundation.org/OPC/DataAccess;s=1:Avant3119961?Disconnect?Default`

Disconnect MethodId: `nsu=http://opcfoundation.org/OPC/DataAccess;s=1:Avant3119961?Disconnect?Default\Disconnect`

Method child browse returned no InputArguments or OutputArguments properties for either method. No arguments are advertised by this browse; zero-argument call is the proposed shape, not a verified successful invocation. [Exact browse evidence](evidence/opc-metadata-reads.json). ConnectSystemTag is Int32; its live EnumValues advertises0=None and1=ConnectSystem. This is observed server enumeration, not a guessed trigger, and no write was tested. Raw AccessLevel/UserAccessLevel remains unavailable from this diagnostic API; do not infer write permission from the presence of a tag. The documented method route is preferable for a separately approved trial.

The actual DataAccess namespace URI is `http://opcfoundation.org/OPC/DataAccess`, currently index2. Exact URI-based read/subscription addressing worked. Method-call URI parsing has not been tested; resolve the current NamespaceArray and use the corresponding `ns=<index>;s=...` ObjectId/MethodId for the approved call. Both strings retain the exact identifier suffix above. NodeIds include the current Default context; manual §4 pp43–44 explains user-specific addressing. Changing account can change addresses. Current configuration is username authentication with Basic256Sha256/SignAndEncrypt, already CONNECTED; no authentication/certificate changes are prerequisites to the present diagnostic read path.

## Approval-gated follow-on procedure

1. Obtain explicit TBMC authorization for the exact ConnectSystem invocation, View-only monitoring, any necessary AssignState=0 write, and conditional Disconnect recovery. Confirm vendor/process owner agrees the session's documented default View applies and no existing session/control will be disrupted. Current commission authorizes none of these calls/writes.
2. Recheck server identity, NamespaceArray, existing AssignState/RunState/UserInControl and current argument metadata. If inputs are unexpectedly advertised, stop for review. Preserve baseline. Never set AssignState=1; never execute Instruction/Method/Setting/Run/Command branches.
3. In Gateway or Perspective scope use the supported Ignition8.3 signature `system.opcua.callMethod(connectionName, objectId, methodId, inputs)` for the discovered ConnectSystem parent/method with `inputs=[]`, only after the prior gate. The function returns overall status, per-input statuses and outputs; retain all three. No call was made here. [Official callMethod documentation](https://www.docs.inductiveautomation.com/docs/8.3/appendix/scripting-functions/system-opcua/system-opcua-callMethod).
4. Read AssignState and require0/View before accepting monitoring. If it is1/Control or another unexpected state, stop and use only the explicitly approved Disconnect recovery; do not continue acquisition or try control-related commands. If default View cannot be confirmed in advance, vendor/TBMC must approve the exact safe ordering for an AssignState=0 write before any connection operation; this ordering is not established by our read-only evidence.
5. Observe matched RunData60–120sec. Require valid quality and non-sentinel values, not merely isGood() (Good_NoData also returns true). Reconcile UV channel, gradient semantics, units and equipment association. A process run must not be started to manufacture data. Record any remaining run-dependent signals separately.
6. Confirm no control ownership or process-setting change; document approved disconnect/release behavior and remove diagnostic subscriptions. Retest addresses if later moving from Default to Ignition_User.

The follow-on is **not yet executable without the explicit approval/vendor ordering gates above**. No automatic initialization or successful View assignment is claimed.
