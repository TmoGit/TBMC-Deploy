@echo off
setlocal
chcp 65001 >nul
title TBMC Ignition Restore Only V3 - corrected DisplayName detection
color 0B
cls
echo ======================================================
echo      TBMC IGNITION RESTORE ONLY - VERSION 3
 echo       Corrected service check / age.exe discovery
 echo       Ignition and MariaDB will NOT be installed
 echo ======================================================
echo.
echo If you do not see VERSION 3 above, stop: wrong launcher.
echo.
set "SCRIPT=%~dp0Migrate-TBMC-Ignition-Existing.ps1"
if not exist "%SCRIPT%" (
  color 0C
  echo ERROR: Patched PowerShell script not found next to launcher.
  echo Extract BOTH files from the ZIP into the SAME folder.
  pause
  exit /b 9
)
rem Do not silently elevate / spawn another window. Require a deliberate administrator run.
net session >nul 2>&1
if errorlevel 1 (
  echo.
  color 0E
  echo IMPORTANT: Right-click this CMD and select Run as administrator.
  echo No changes were made.
  pause
  exit /b 5
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
set "RESULT=%ERRORLEVEL%"
echo.
echo ======================================================
echo VERSION 3 FINISHED - Exit code: %RESULT%
echo Readiness report: C:\TBMC\Logs\TBMC-Ignition-Restore-Readiness.json
echo No software installers were launched by this wrapper.
echo ======================================================
echo.
pause
exit /b %RESULT%
