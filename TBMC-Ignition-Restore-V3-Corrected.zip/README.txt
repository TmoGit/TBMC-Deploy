TBMC Ignition restore-only — VERSION 3 (direct replacement)

WHY THIS VERSION:
The previous patch included a newly named *-Fixed.ps1, but the CMD
running on your desktop continued calling the old Migrate-TBMC-Ignition-Existing.ps1.
The screenshot confirms the old line 91 was still executing. This version
places the repair under the EXACT filename expected by the launcher, and
introduces an unmistakable version-3 CMD launcher.

WHAT TO DO:
1. Download this ZIP into your Ignition Windows server.
2. Create a NEW desktop folder named TBMC-Restore-V3.
3. Extract the ZIP into THAT folder (not the existing TBMC-Deploy-main folder).
4. Right-click RUN-TBMC-IGNITION-V3.cmd -> Run as administrator.
5. Confirm the console says 'TBMC IGNITION RESTORE ONLY - VERSION 3'.
6. Check preflight output. Do not type RESTORE until you've backed up the
   current destination and confirmed the artifacts are complete.

The CMD launches the patched Migrate-TBMC-Ignition-Existing.ps1 stored
NEXT TO IT. It does not call the older file elsewhere on the desktop.

Corrections:
- Avoids StrictMode failure when some service/registry objects lack
  a DisplayName property.
- Looks for age.exe under C:\TBMC\Tools\age\age.exe and tests its version.
- Retains safeguards for encrypted artifacts, Ignition 8.3.4, MariaDB 10.11,
  live connections, and a deliberate RESTORE confirmation.
- Does NOT reinstall Ignition or MariaDB.

Preflight report: C:\TBMC\Logs\TBMC-Ignition-Restore-Readiness.json

Note: The original repository ignition\Restore-Ignition.ps1 is not included
and has not been tested here; it is invoked after preflight and approval.
Do not treat a passed preflight as proof of a successful application restore.
